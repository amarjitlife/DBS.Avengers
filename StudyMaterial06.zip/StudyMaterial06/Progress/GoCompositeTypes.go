
package main 

import (
	"fmt"
	"math/rand"
	"strings"
	"bufio"
	"strconv"
	"os"
)


//_______________________________________________

func playWithBitwiseOperators() {
	var x = 10
	var y = 99
	
	fmt.Printf("\n%b", x)
	fmt.Printf("\n%b", y)

	fmt.Printf("\n%b", x | y )
	fmt.Printf("\n%b", x & y )
	fmt.Printf("\n%b", x ^ y )
}

//_______________________________________________

// Given operands a, b
// AND(a, b) = 1; only if a = b = 1
//                else = 0

func playWithBitwiseAndOperator() {
    var x uint8 = 0xAC    // x = 10101100

	// x = 		1010 1100
	//	   & 	11110000

	fmt.Printf("\n%b", x)
    x &= 0xF0             // x = 10100000
	fmt.Printf("\n%b", x)
}

func playWithBitwiseAndOperatorUseCase() {
    for x := 0; x < 100; x++ {
        num := rand.Int()
        if num & 1 == 1 {
            fmt.Printf("%d is odd\n", num)
        } else {
            fmt.Printf("%d is even\n", num)
        }
    }
}

// Given operands a, b
// OR(a, b) = 1; when a = 1 or b = 1
//               else = 0 

func playWithBitwiseOrOperator() {
    var x uint8 = 10 		// 		00001010
    x |= 196  				// | 	11000100
    fmt.Printf("\n%b", x)   // 		11001110
}

// Given operands a, b
// XOR(a, b) = 1; only if a != b
//      else = 0

func playWithBitwiseXorOperator0() {
    var x uint16 = 0xCEFF	// 	  1100 1110 1111 1111
    x ^= 0xFF00 			// 	^ 1111 1111 0000 0000

    fmt.Printf("\n%b", x)   // 0011 0001 1111 1111
}

func playWithBitwiseXorOperator1() {
    var x byte = 0x0F  			//0000 1111
    fmt.Printf("%08b\n", x) 	//0000 1111	
    fmt.Printf("%08b\n", ^x) 	//1111 0000

    // In Go ^x = 1 ^ x which reverses Bit In x
}

// Given operands a, b
// AND_NOT(a, b) = AND(a, NOT(b))
	
	// AND_NOT(a, 1) = 0; clears a
	// AND_NOT(a, 0) = a; 

func playWithBitwiseAndNotOperator() {
    var x byte = 0xAB         	// 	1010 1011
     
     fmt.Printf("%08b\n", x)    // 		1010 1011
     x &^= 0x0F                 //&^ 	0000 1111   
     fmt.Printf("%08b\n", x)    //		1010 0000
}


//_______________________________________________

type Flags uint

const (
	FlagUp Flags 	= 1 << iota
	FlagBroadcast
	FlagLoopback
	FlagPointToPoint
	FlagMulticast
)

func IsUp(v Flags) bool 	{ return v & FlagUp == FlagUp }
func TurnDown(v *Flags)		{ *v &^= FlagUp } // &^ (AND NOT) This Will Clear Bit
func SetBroadcast(v *Flags) { *v |= FlagBroadcast }
func IsCast(v Flags) bool 	{ return v & (FlagBroadcast | FlagMulticast ) != 0 }

func playWithFlags() {
	var v Flags = FlagMulticast | FlagUp

	fmt.Printf("%b %t\n", v, IsUp( v ) )
	TurnDown( &v )
	fmt.Printf("%b %t\n", v, IsUp( v ) )

	SetBroadcast( &v )
	fmt.Printf("%b %t\n", v, IsUp( v ) )
	fmt.Printf("%b %t\n", v, IsCast( v ) )
}

// Operator precedence
// Unary operators have the highest precedence. 
// As the ++ and -- operators form statements, not expressions, 
// they fall outside the operator hierarchy. 
// As a consequence, statement *p++ is the same as (*p)++.

// There are five precedence levels for binary operators. 
// Multiplication operators bind strongest, 
// followed by addition operators, comparison operators, 
// && (logical AND), and finally || (logical OR):

// Precedence    	Operators
//     5             *  /  %  <<  >>  &  &^
//     4             +  -  |  ^
//     3             ==  !=  <  <=  >  >=
//     2             &&
//     1             ||

// Binary operators of the same precedence associate from 
// left to right. For instance, x / y * z is the same as (x / y) * z.

//NOTE : Precedence Order and Rules Are Not Same In Go and C
// 		https://go.dev/ref/spec#Operators
// 		https://en.cppreference.com/w/c/language/operator_precedence

//_______________________________________________

const (
	UPPER = 1 // upper case
	LOWER = 2 // lower case
	CAP   = 4 // capitalizes
	REV   = 8 // reverses
)

func processString(str string, conf byte) string {
    // reverse string
	rev := func(s string) string {
		runes := []rune(s)
		n := len(runes)
		for i := 0; i < n/2; i++ {
			runes[i], runes[n-1-i] = runes[n-1-i], runes[i]
		}
		return string(runes)
	}
	
	// query configs
	if (conf & UPPER) != 0 {
		str = strings.ToUpper(str)
	}
	if (conf & LOWER) != 0 {
		str = strings.ToLower(str)
	}
	if (conf & CAP) != 0 {
		str = strings.Title(str)
	}
	if (conf & REV) != 0 {
		str = rev(str)
	}
	return str
}

func playWithProcessString() {
	fmt.Println( processString("HELLO PEOPLE!", LOWER|REV|CAP) )
}

//_______________________________________________

func playWithArrays() {
	// Initialised To Zero Of Type int
	var a [3]int

	for index, value := range a {
		fmt.Printf("\nAt Index : %d, Value : %d", index, value)
	}
	fmt.Println( a[0] )
	fmt.Println( a[1] )
	fmt.Println( a[2] )
	// Compilation Error
	// invalid argument: array index 3 out of bounds [0:3]
	// fmt.Println( a[3] )
	fmt.Println( a[ len(a) - 1 ] )
	for _, value := range a {
		fmt.Println( value )
	}

	var q [5]int = [5]int { 10, 20, 30, 40, 50 }
	var r [5]int = [5]int { 10, 20, 30 }

	fmt.Println("\nArray Length: ", len( q ) )
	for index, value := range q {
		fmt.Printf("\nAt Index : %d, Value : %d", index, value)
	}

	fmt.Println("\nArray Length: ", len( r ) )
	for index, value := range r {
		fmt.Printf("\nAt Index : %d, Value : %d", index, value)
	}

	s := [...]int{ 10, 20, 30, 111 }
	fmt.Println("\nArray Length: ", len( s ) )
	for index, value := range s {
		fmt.Printf("\nAt Index : %d, Value : %d", index, value)
	}

	some := [3]int{ 100, 200, 300 }
	fmt.Println("\nArray Length: ", len( some ) )
	fmt.Printf("\nData Type: %T", some )

	someAgain := [...]int{ 99 : -1  }
	fmt.Println("\nArray Length: ", len( someAgain ) )
	fmt.Printf("\nData Type: %T", someAgain )

	fmt.Println()
	for index, value := range someAgain {
		fmt.Printf(" Index : %d, Value : %d ###", index, value)
	}

	fmt.Println()
	fmt.Println( q )
	fmt.Println( r )
	fmt.Println( s )
	fmt.Println( some )
	fmt.Println( someAgain )

	aa := [2]int { 10, 20 }
	bb := [...]int {10, 20 }
	cc := [2]int { 10, 30 }

	fmt.Println( aa == bb, aa == cc, bb == cc )

	// Compilation Error
	// invalid operation: cc == dd (mismatched types [2]int and [3]int)
	// dd := [3]int { 10, 30 }
	// fmt.Println( cc == dd )
}

//_______________________________________________

// In C/C++/Java By Default:
//		Arrays Are Pass By Reference

// In Go By Default:
//		Arrays Are Pass By Value
//		Function Will By Default Creates Local Copy 
// 			Of The The Whole Arrayi.e. All It's Elements

func changeArray( a [5]int ) {
	for i, _ := range a {
		a[ i ] = 777;
	}
	fmt.Println( "Array Inside Function: ", a )
}

func changeArrayAgain( a *[5]int ) {
	for i, _ := range a {
		a[ i ] = 777;
	}
}

func playWithChangeArray() {
	var aa [5]int = [5]int { 10, 20, 30, 40, 50 }

	fmt.Println("Array Elements Before changeArray :", aa )
	changeArray( aa )
	fmt.Println("Array Elements After  changeArray :", aa )

	fmt.Println("Array Elements Before changeArrayAgain :", aa )
	changeArrayAgain( &aa )
	fmt.Println("Array Elements After  changeArrayAgain :", aa )
}

//_______________________________________________

type Currency int

const (
	USD Currency = iota
	EUR
	GBP = 4
	RMB
)

func playWithCorrency() {
	fmt.Println( USD, EUR, GBP, RMB )
}

func zero( ptr * [10]byte ) {
	for i := range ptr {
		ptr[i] = 0
	}
}

func zeroAgain( ptr * [10]byte ) {
	*ptr = [10]byte { }
}

func playWithArraysAgain() {
	q := [...]int { 1, 2, 3 }

	fmt.Printf("\n%T ", q)
	fmt.Println( q )

	qq := [3]int { 1, 2, 3 }
	// cannot use [4]int{…} (value of type [4]int) as type [3]int in assignment
	// qq  = [4]int { 10, 30, 30, 40 }
	fmt.Println( qq )

	p := [...]byte { 1, 1, 2, 3, 4, 8, 7, 9, 8, 9 }
	fmt.Println( p )
	zero( &p )
	fmt.Println( p )

	pp := [...]byte { 1, 1, 2, 3, 4, 8, 7, 9, 8, 9 }
	fmt.Println( pp )
	zeroAgain( &pp )
	fmt.Println( pp )
}

//_______________________________________________

// In C/C++/Java
// 		changeArrayAgain1 Function Takes Argument Array of Int
// int changeArrayAgain1( int a[] ) {

// }

// In Go Lang
// 		changeArrayAgain1 Function Takes Argument Slice Of Int Array

// cannot use cc (variable of type [10]int) as type []int in argument
func changeArrayAgain1( a []int ) {
	for i, _ := range a {
		a[ i ] = 777;
	}
}

func playWithArraysAndSlices() {
	var cc [10]int = [10]int{ 10, 20, 30, 40, 50, 60, 70, 80, 90, 00 }

	var slice = cc[ : 5 ]
	fmt.Println( slice )

	slice = cc[ 4 :  ]
	fmt.Println( slice )

	slice = cc[ 3 : 7 ]
	fmt.Println( slice )

	//invalid argument: array index 12 out of bounds [0:11
	// slice = cc[ 3 : 12 ]
	// fmt.Println( slice )
	slice = cc[ : ]
	fmt.Println( slice )

	fmt.Println( cc ) 
	// Passing Slice To Function
	//		Slices Are Pass By Reference
	changeArrayAgain1( cc[ : 2 ] )
	fmt.Println( cc )	

	fmt.Println( cc ) 
	// Passing Slice To Function
	//		Slices Are Pass By Reference
	changeArrayAgain1( cc[ 7 :  ] )
	fmt.Println( cc )	

	fmt.Println( cc ) 
	// Passing Slice To Function
	//		Slices Are Pass By Reference
	changeArrayAgain1( cc[  :  ] )
	fmt.Println( cc )	
}

//_______________________________________________

func playWithArrayAndSlicesEquality() {
	var a1 [5]int = [...]int{ 10, 20, 30, 40, 50 }
	fmt.Println( a1 )

	var b1 [5]int = [...]int{ 10, 20, 30, 40, 50 }
	fmt.Println( b1 )

	var c1 [5]int = [...]int{ 10, 20, 30, 40, 60 }
	fmt.Println( c1 )

	fmt.Println( a1 == b1, a1 == c1, b1 == c1 )
	// cannot use [...]int{…} (value of type [4]int) as type 
	// [5]int in variable declaration
	// var aa [5]int = [...]int{ 10, 20, 30, 40 }

	var cc [10]int = [10]int{ 10, 20, 30, 40, 50, 60, 70, 80, 90, 00 }
	var slice1 = cc[ : 5 ]
	var slice2 = cc[ : 5 ]

	fmt.Println( slice1 )
	fmt.Println( slice2 )

	// Compilation Error
	// invalid operation: slice1 == slice2 (slice can only be compared to nil)
	// fmt.Println( slice1 == slice2 )
	slice1 = nil
	slice2 = nil

	fmt.Println( slice1, slice2 )
	fmt.Println( slice1 == nil , slice2 == nil  )
}

//_______________________________________________


func playWithMonthsSlices( ) {
	months := [...]string { 0 : "", "Jan", "Feb", "Mar", "Apr", "May", "Jun",
			"Jul", "Aug", "Sep", "Oct", "Nov", "Dec" }

	fmt.Println( "Months: ", months )

	quater1 := months[ 1 : 4 ]
	quater2 := months[ 4 : 7 ]
	summer  := months[ 3 : 8 ]

	fmt.Println("Quater 1 : ", quater1 )	
	fmt.Println("Quater 2 : ", quater2 )	
	fmt.Println("Summer   : ", summer )	

	for _, s := range summer {
		for _, q := range quater2 {
			if s == q {
				fmt.Printf("\n %s  Appears In Both", s )
			}
		}
	}
}



//______________________________________________________________________
// 						
// 						GO SLICES CONCEPTS
//______________________________________________________________________

// Slices represent variable-length sequences whose elements all 
// have the same type. A slice type is written []T, where the 
// elements have type T; 
// 		it looks like an array type without a size.

// A slice is a lightweight data structure that gives access to 
// a subsequence (or perhaps all) of the elements of an array, 
// which is known as the slice’s underlying array. 

// 	A slice has three components: a pointer, a length, and a capacity. 
// 		The pointer points to the first element of the array that 
//			is reachable through the slice, which is not necessarily 
//			the array’s first element. 
// 		The length is the number of slice elements; it can’t 
//			exceed the capacity, which is usually the number of elements between 
// 			the start of the slice and the end of the underlying array. 

// 		The built-in functions len and cap return those values.

// The slice operator s[ i : j ], where 0 ≤ i ≤ j ≤ cap(s), 
// 	Creates a new slice that refers to elements i through 
//  j-1 of the sequence s,  which may be an array variable, 
//  a pointer to an array, or another slice. 
// 	The resulting slice has j-i elements. 
// 	If i is omitted,it’s 0,and if j isomitted, it’s len(s). 

// 	Thus the slice months[1:13] refers to the whole range of 
//  valid months,  as does the slice months[1:]; 
//  the slice months[:] refers to the whole array.


//_______________________________________________

// THINK LIKE C AND CODE LIKE PYTHON

func playWithModifiicationsUsingSlices( ) {
	numbers := [...]int { 10, 20, 30, 40, 50, 60, 70, 80, 90, 11, 22, 33, 44 }

	fmt.Println( "Months: ", numbers )

	numbersQuater1 := numbers[ 1 : 4 ]
	numbersQuater2 := numbers[ 4 : 7 ]
	commonSlice    := numbers[ 3 : 8 ]

	fmt.Println("Quater 1 : ", numbersQuater1 )	
	fmt.Println("Quater 2 : ", numbersQuater2 )	
	fmt.Println("Commmon  : ", commonSlice )	

	for i := range commonSlice {
		commonSlice[ i ] = 0 
	}

	fmt.Println("Quater 1 : ", numbersQuater1 )	
	fmt.Println("Quater 2 : ", numbersQuater2 )	
	fmt.Println("Commmon  : ", commonSlice )	

	numbersAgain := [...]int { 10, 20, 30, 40, 50, 60, 70, 80, 90, 11, 22, 33, 44 }

	numbersAgainQuater1 := numbersAgain[ 1 : 4 ]

	fmt.Println("Numbers Quater1  : ", numbersAgainQuater1 )	
	fmt.Println("Numbers Quater1  : ", numbersAgainQuater1[ : ]  )	

	fmt.Println("Numbers Quater1  : ", numbersAgainQuater1[ : 4 ]  )
	// Numbers Quater1  :  [20 30 40 50]
	// Above Slice Will Pick Elements With Following Logic
	//for ( i = 0, element =  1 + i ; i < 4 ; i++  ) { numbersAgainQuater1[ element ] }
	
	fmt.Println("Numbers Quater1  : ", numbersAgainQuater1[ : 12 ]  )	
	fmt.Println("Numbers Quater1  : ", numbersAgainQuater1[ 4 : 12 ]  )	
	// Numbers Quater1  :  [60 70 80 90 11 22 33 44]
	// Above Slice Will Pick Elements With Following Logic
	//for ( i = 0, element =  4 + i ; i < 12 ; i++  ) { numbersAgainQuater1[ element ] }
	
	numbersOnceMore := numbersAgainQuater1[ 3 : 7 ]
	fmt.Println( numbersOnceMore )
	fmt.Println( numbersOnceMore[ 2 : 4 ] )

	// Runtime Error
	// panic: runtime error: slice bounds out of range [:13] with capacity 12	
	// fmt.Println("Numbers Quater1  : ", numbersAgainQuater1[ : 13 ]  )	
}

//_______________________________________________

func reverse( s []int ) {
	for i, j := 0, len( s ) - 1 ;  i < j  ;  i, j = i + 1, j - 1  {
		s[i], s[j] = s[j], s[i]
	}
}

// Following Both Style Of Functions Arguments Are Equivalent

func playWithReverse() {
	a := [...]int{ 10, 20, 30, 40, 50, 60, 70, 80, 90, 99 }

	fmt.Println( a )
	reverse( a [ : ] )
	fmt.Println( a )

	reverse( a [ : 4 ] )
	fmt.Println( a )

	reverse( a [ 7 :  ] )
	fmt.Println( a )

	// reverse( a )
	// fmt.Println( a )
}

//_______________________________________________

// func equalSlices(x []int, y []int )
func equalSlices( x, y []int ) bool {
	if len( x ) != len( y ) {
		return false
	}

	for i := range x {
		if x[i] != y[i] {
			return false
		}
	}
	return true
}

func playWithEqualSlices() {
	a := [...]int{ 10, 20, 30, 40, 50, 60, 70, 80, 90, 99 }

	slice1 := a[ 2 : 7 ]
	slice2 := a[ 2 : 7 ]
	slice3 := a[ 1 : 7 ]

	fmt.Println("Slices Equal : ", equalSlices( slice1, slice2 ) )
	fmt.Println("Slices Equal : ", equalSlices( slice1, slice3 ) )
	fmt.Println("Slices Equal : ", equalSlices( slice2, slice3 ) )
}

//_______________________________________________

// The built-in function make creates a slice of a specified 
// element type, length, and capacity. The capacity argument 
// may be omitted, in which case the capacity equals the 
// length.
// 		make([]T, len)
// 		make([]T, len, cap) // same as make([]T, cap)[:len]

func playWithArraysAndSlicesFunctions() {
	s := make( []string, 3 )

	fmt.Println("Empty Slice: ", s )
	fmt.Printf("\nEmpty Slice Type: %T", s )
	fmt.Printf("\nLength: %d Capacity: %d", len( s ), cap( s ) )

	s[0] = "Ding"
	s[1] = "Dong"
	s[2] = "Ting"

	fmt.Println("\nSlice: ", s )
	fmt.Printf("\nLength: %d Capacity: %d", len( s ), cap( s ) )

	s = append( s, "Tong" )
	fmt.Println("\nSlice: ", s )
	fmt.Printf("\nLength: %d Capacity: %d", len( s ), cap( s ) )	

	s = append( s, "Ping" )
	s = append( s, "Pong" )
	fmt.Println("\nSlice: ", s )
	fmt.Printf("\nLength: %d Capacity: %d", len( s ), cap( s ) )	

	s = append( s, "Zing" )
	fmt.Println("\nSlice: ", s )
	fmt.Printf("\nLength: %d Capacity: %d", len( s ), cap( s ) )	

	c := make( []string, len( s ) )
	// Shallow Copy
	c = s // Reference Assignment

	fmt.Println("\nSlice s: ", s )
	fmt.Println("Slice c: ", c )

	s[0] = "Hello!"

	fmt.Println("Slice s: ", s )
	fmt.Println("\nSlice c: ", c )

	ss := make( []string, 0 )	
	fmt.Println("\nSlice ss: ", ss )
	fmt.Printf("\nLength: %d Capacity: %d", len( ss ), cap( ss ) )	

	ss = append( ss, "AA", "BB", "CC", "DD", "EE" )
	fmt.Println("\nSlice ss: ", ss )
	fmt.Printf("\nLength: %d Capacity: %d", len( ss ), cap( ss ) )	

	cc := make( []string, len ( ss ) )
	fmt.Println("Slice ss: ", ss )
	fmt.Println("Slice cc: ", cc )

	// Deep Copy : Complete Duplicate Of Obect Created
	copy( cc, ss )
	fmt.Println("\nSlice ss: ", ss )
	fmt.Println("Slice cc: ", cc )

	ss[0] = "Good Afternoon!!!"
	fmt.Println("\nSlice ss: ", ss )
	fmt.Println("Slice cc: ", cc )

	// Creating Slice Using Declarative Syntax
	tt := []string{ "Ding", "Dong", "Ting", "Tong" }
	fmt.Println("\nSlice tt: ", tt )
	fmt.Printf("\nSlice tt Type %T: ", tt )
	fmt.Printf("\nLength: %d Capacity: %d", len( tt ), cap( tt ) )	

	tt = append(tt, "Ping")
	fmt.Printf("\nLength: %d Capacity: %d", len( tt ), cap( tt ) )	
	fmt.Println("\nSlice tt: ", tt )

	// fmt.Println( tt[6] ) 	// tt[ 6 ] Using Indexing Operator
	fmt.Println( tt[ 2 : 7 ] )	// tt[ 2 : 7 ] Is Slicing Operator
}

// https://codebunk.com/b/9051100497618/
// https://codebunk.com/b/9051100497618/
// https://codebunk.com/b/9051100497618/

//_______________________________________________


func playWithReadingUserInputs() {

	input := bufio.NewScanner( os.Stdin )

	outer:
		for input.Scan() {
			var ints []int 

			for _, s := range strings.Fields( input.Text() ) {
				x, err := strconv.ParseInt(s, 10, 64 )

				if err != nil {
					fmt.Fprintln( os.Stderr, err )
					continue outer
				}
				ints = append( ints, int( x ) )
			}

			fmt.Printf("%v\n", ints)
			reverse( ints )
			fmt.Printf("%v\n", ints)
		}
}


//_______________________________________________


func playWith2DimentionalData(rows, columns int ) {
	twoDimentionalArray := make( [][]int, 3 ) 

	for  row := 0 ; row < rows ; row++  {
		innerLen := row + 1

		twoDimentionalArray[ row ] = make( []int, innerLen )

		for column := 0 ; column < innerLen ; column++  {
			twoDimentionalArray[ row ] [ column ] = row + column 
		}
	}

	fmt.Println("2 Dimentional Array:", twoDimentionalArray )
}



//_______________________________________________
//_______________________________________________
//_______________________________________________
//_______________________________________________
//_______________________________________________
//_______________________________________________
//_______________________________________________


func main() {
	fmt.Println("\n\nFunction : playWithArrays")
	playWithArrays()

	fmt.Println("\n\nFunction : playWithBitwiseOperators")
	playWithBitwiseOperators()

	fmt.Println("\n\nFunction : playWithFlags")
	playWithFlags()

	fmt.Println("\n\nFunction : playWithChangeArray")
	playWithChangeArray()

	fmt.Println("\n\nFunction : playWithCorrency")
	playWithCorrency()

	fmt.Println("\n\nFunction : playWithArraysAgain")
	playWithArraysAgain()

	fmt.Println("\n\nFunction : playWithArraysAndSlices")
	playWithArraysAndSlices()

	fmt.Println("\n\nFunction : playWithArrayAndSlicesEquality")
	playWithArrayAndSlicesEquality()

	fmt.Println("\n\nFunction : playWithMonthsSlices")
	playWithMonthsSlices()

	fmt.Println("\n\nFunction : playWithModifiicationsUsingSlices")
	playWithModifiicationsUsingSlices()

	fmt.Println("\n\nFunction : playWithReverse")
	playWithReverse()

	fmt.Println("\n\nFunction : playWithEqualSlices")
	playWithEqualSlices()

	fmt.Println("\n\nFunction : playWithArraysAndSlicesFunctions")
	playWithArraysAndSlicesFunctions()

	fmt.Println("\n\nFunction : playWithReadingUserInputs")
	playWithReadingUserInputs()

	fmt.Println("\n\nFunction : playWith2DimentionalData")
	playWith2DimentionalData( 4, 3 )

	// fmt.Println("\n\nFunction : ")
	// fmt.Println("\n\nFunction : ")
	// fmt.Println("\n\nFunction : ")
	// fmt.Println("\n\nFunction : ")
	// fmt.Println("\n\nFunction : ")
	// fmt.Println("\n\nFunction : ")
	// fmt.Println("\n\nFunction : ")
	// fmt.Println("\n\nFunction : ")
	// fmt.Println("\n\nFunction : ")
	// fmt.Println("\n\nFunction : ")
}


// Java program to Demonstrate How to
// Implement Static and Non-static Classes

class StaticExample {
	// Input string
	public static String message = "GeeksForGeeks";
	public String hello = "Hello!";
}

class StaticDemoSimple {
	public static void main(String args[]) {
		StaticExample staticExample = new StaticExample();
		staticExample.message 	= "Ding Dong";
		staticExample.hello 	= "Dingo Dongo";

		StaticExample staticExampleAgain = new StaticExample();
		staticExampleAgain.message 	= "Ting Tong";
		staticExampleAgain.hello 	= "Tingo Tongo";

		System.out.println( staticExample.hello );
		System.out.println( staticExample.message );	

		System.out.println( staticExampleAgain.hello );
		System.out.println( staticExampleAgain.message );
	}
}

// Dingo Dongo
// Ting Tong
// Tingo Tongo
// Ting Tong


#include <stdio.h>

int main() {
	int participantsCount = 7;
	
	printf("\nHello World!!!");
	printf("\nWelcome To Go Language Training!!!");
}

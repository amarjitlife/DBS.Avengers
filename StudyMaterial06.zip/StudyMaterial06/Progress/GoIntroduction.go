	
package main

import "fmt"
import "math"
import "time"
import "os"
import "strings"
import "math/rand"


//_______________________________________________

func helloWorld() {
	fmt.Println("Hello World!!!")
}

//_______________________________________________

func playWithValues() {
	fmt.Println("Go" + "Language")
	fmt.Println( "10+ 20", 10 + 20 )
	fmt.Println( "10.9     + 20.9", 10.9 + 20.9 )

	fmt.Println( true && false )
	fmt.Println( true || false )
	fmt.Println( !true )
	fmt.Println( !false )
}

//_______________________________________________

func playWithVariable() {
	// Creating a Variable With String Type Initial Value
	// Implicitly Inferred Type Of a Variable Is string
	var a = "Good Afternoon!"
	fmt.Println( a )

	// Explicitly Specifying Type of b And c As int
	var b, c int = 1, 2 
	fmt.Println( b, c )

	// Implicitly Inferred Type From RHS Value
	//		Hence b Type Will Be Boolean
	var d = true
	fmt.Println( d )

	// Explicitly Specifying Type of e As int
	//		Default Value For int Type Will Be 0
	var e int 
	fmt.Println( e )

	// f Will Be Created Immutable Value Of Type string
	f := "Apples and Manoges "
	fmt.Println( f )
}

//_______________________________________________

const s string = "Some Constant Value"

func playWithConstants() {
	fmt.Println( s )

	const dbsStartingSalary = 890000
	fmt.Println( dbsStartingSalary )

	const count = 3e20 / dbsStartingSalary
	fmt.Println( count )

	fmt.Println( int64( dbsStartingSalary ) )
	fmt.Println( math.Sin( math.Pi / 2 ) )

	// Following Will Give Compilation Errors
	// const Are Immutable In Nature
	// s = "Something else"
	// dbsStartingSalary = dbsStartingSalary + 200000
}

//_______________________________________________

func playWithForLoop() {	
	// Short Hand Notation
	i := 1
	for i <= 3 {
		fmt.Println( i )
		i++
	}

	for j := 7 ; j <= 11 ; j++ {
		fmt.Println( j )
	} 

	// Infinite Loop Because Default Value Of Condition Is true
	// for { 
	// 	fmt.Println("Loop")
	// }

	for n := 0 ; n <= 5 ; n++ {
		if n % 2 == 0 {
			continue
		}
		fmt.Println( n )
	}
}

//_______________________________________________

func playWithIfElse() {
	if 7 % 2 == 0 {
		fmt.Println("7 Divisible By 2")
	} else {
		fmt.Println("7 Not Divisible By 2")
	}

	if  8 % 4 == 0 {
		fmt.Println("8 Divisible By 4")
	}

	if num := 9 ; num < 0 {
		fmt.Println("Number Is Negative")
	} else if num == 0 {
		fmt.Println("Number Is Zero")		
	} else {
		fmt.Println("Number Is Positive")		
	}
}

//_______________________________________________

func playWithSwitch() {
	i := 2

	fmt.Println("Integer's English Vocal Values")
	// For Each case
	// break Is Implicit In Go Laguage
	switch i {
	// expression i == 0
	case 0 :
		fmt.Println( "Zero" )
	case 1 :
		fmt.Println( "One" )
	case 2 :
		fmt.Println( "Two" )
	case 3 :
		fmt.Println( "Three" )
	}

	switch time.Now().Weekday() {
	case time.Saturday, time.Sunday:
		fmt.Println("Happy Weekends!!! Lets Enjoy!!!")
	default:
		fmt.Println("Work Weekdays!!! Lets Work!!!")		
	}

	t := time.Now()
	switch {
	case t.Hour() < 12: 
		fmt.Println("Before Noon...")		
	default:
		fmt.Println("After Noon...")
	}
}

//_______________________________________________

func plus( a int, b int ) int {
	return a + b 
}

func factorial( n int ) int {
	if n < 0 {
		fmt.Println("factorial For Negative Values Undefined!")
		return -1
	}

	var result int = 1
	if n == 0 || n == 1 {
		return result
	} else {
		for n > 1 {
			result = result * n
			n--
		}
		return result
	}
}

func factorialRecursive( n int ) int {
	if n < 0 {
		fmt.Println("factorial For Negative Values Undefined!")
		return -1
	}

	if n == 0 || n == 1 {
		return 1
	} else {
		return n * factorialRecursive( n - 1 )
	}
}


func playWithPlusAndFactorial() {
	fmt.Println( plus( 20, 30 ) )
	fmt.Println( plus( 90, -30 ) )

	fmt.Println( factorial( 4 ) )
	fmt.Println( factorial( 5 ) )

	fmt.Println( factorialRecursive( 4 ) )
	fmt.Println( factorialRecursive( 5 ) )
}

//_______________________________________________

func playWithCommandLineArguments() {
	var combinedString, seperator string
	seperator = "   "
	for i := 1 ; i < len( os.Args ) ; i++ {
		passedValues := os.Args[i]

		fmt.Println( passedValues )

		combinedString += seperator + passedValues
	}

	fmt.Println( "Combined Value: ", combinedString )

// import "strings"

	combinedStringAgain := strings.Join( os.Args[ 1 : ], "   " )
	fmt.Println( "Combined Value Again: ", combinedStringAgain )
}

//_______________________________________________

func playWithRandomNumbers() {
	randomNumber := rand.Intn( 100 )
	fmt.Println( "Random Number: ", randomNumber )

 	s1 := rand.NewSource(time.Now().UnixNano())
    r1 := rand.New(s1)
	fmt.Println( "Random Number: ", r1 )
}


//_______________________________________________

func playWithMathsFunctions() {
	var number float64 = 625.0

	fmt.Println("\n Square Root   : ", math.Sqrt( number) )
	fmt.Println("\n Maximum Value : ", math.Max( 900, 9000 ) )
	fmt.Println("\n Minimum Value : ", math.Min( 900, 9000 ) )
	fmt.Println("\n Minimum Value : ", math.Pow( 2, 10 ) )
	fmt.Println("\n Minimum Value : ", math.Pow( 5, 3 ) )
}


//_______________________________________________


func playWithRangeOperator() {
	something, seperator := "", " #%%# "

	for index, value := range os.Args[ 1 : ] {
		fmt.Println( index, value  )
		something = something + seperator + value
	}

	fmt.Println( something )
}


//_______________________________________________
//_______________________________________________
//_______________________________________________
//_______________________________________________

func main() {
	fmt.Println("\nFunction : helloWorld")
	helloWorld()

	fmt.Println("\nFunction :playWithValues")
	playWithValues()
	
	fmt.Println("\nFunction : playWithConstants")
	playWithConstants()

	fmt.Println("\nFunction : playWithForLoop")
	playWithForLoop()

	fmt.Println("\nFunction : playWithIfElse")
	playWithIfElse()

	fmt.Println("\nFunction : playWithSwitch")
	playWithSwitch()

	fmt.Println("\nFunction : playWithPlusAndFactorial")
	playWithPlusAndFactorial()

	fmt.Println("\nFunction : playWithCommandLineArguments")
	playWithCommandLineArguments()

	fmt.Println("\nFunction : playWithRandomNumbers")
	playWithRandomNumbers()

	fmt.Println("\nFunction : playWithMathsFunctions")
	playWithMathsFunctions()

	fmt.Println("\nFunction : playWithRangeOperator")
	playWithRangeOperator()

	// fmt.Println("\nFunction : ")
	// fmt.Println("\nFunction : ")
	// fmt.Println("\nFunction : ")
	// fmt.Println("\nFunction : ")
	// fmt.Println("\nFunction : ")
	// fmt.Println("\nFunction : ")
	// fmt.Println("\nFunction : ")
	// fmt.Println("\nFunction : ")
	// fmt.Println("\nFunction : ")
}


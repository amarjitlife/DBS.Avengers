/*
// Compiling And Running C Code
	gcc Experiment.c -o experiment
	./experiment
*/

#include <stdio.h>
#include <limits.h>

int globalVariable = 0;

int playWithVariables() {
	int e;
	printf("\nValue of e : %d", e);
}

//_________________________________________________________


void playWithSizeof() {
	char 	cc = 'A';
	int 	ii = 20;
	float 	ff = 30.9;
	double 	dd = 100.0;

	printf("\n Size char   type: %ld", sizeof( cc ) );
	printf("\n Size int    type: %ld", sizeof( ii ) );
	printf("\n Size float  type: %ld", sizeof( ff ) );
	printf("\n Size double type: %ld", sizeof( dd ) );

	char 	* cptr = &cc;
	int  	* iptr = &ii;
	float 	* fptr = &ff;
	double  * dptr = &dd;

	printf("\n Size char   * type: %ld", sizeof( cptr ) );
	printf("\n Size int    * type: %ld", sizeof( iptr ) );
	printf("\n Size float  * type: %ld", sizeof( fptr ) );
	printf("\n Size double * type: %ld", sizeof( dptr ) );
}


//_________________________________________________________


void playWithPointers() {
	int a = 20;

	int 	  *address1 	= &a;
	int 	 **address2 	= &address1;
	int 	***address3 	= &address2;
	int    ****address4 	= &address3;

	printf("\n %p %p", address4, *address4 );
	printf("\n %p %p", address3, *address3 );
	printf("\n %p %p", address2, *address2 );
	printf("\n %p %d", address1, *address1 );

	printf("\n %p", **address4 );
	printf("\n %p", **address3 );
	printf("\n %d", **address2 );

	printf("\n %d", ***address3 );
	printf("\n %d", **address2 );
	printf("\n %d", *address1 );
}


//_________________________________________________________

void playWithForLoopScope() {
	int something = 99;

	// i Is Local To for Loop
	for( int i = 0 ; i < 5 ; i++ ) {
		printf("\n i Value : %d and Something : %d", i, something );
	}

	// i = i + 1;
}

//_________________________________________________________

void playWithArrays() {
	int a[ 5 ] = { 10, 20, 30, 40, 50 };

	for( int i = 0; i < 5 ; i++) {
		if ( i < 5 ) {
			printf("\nAt Index %d Value %d", i, a[i] );
		} else {			
			printf("\nIndex Out Of Bound");
		}
	}
}

//_________________________________________________________

void playWithArraysAndPointers0() {
	int a[ 5 ] = { 10, 20, 30, 40, 50 };
	int *ptr = a;
	for( int i = 0 ; i < 5 ; i++ ) {
		printf("\nAt Index %d Value %d", i, *(ptr + i) );
	}
}

//_________________________________________________________

void playWithArraysAndPointers1() {
	int i = 0;
	int a[ 5 ] = { 10, 20, 30, 40, 50 };
	for( int *ptr = a ; i < 5 ; ptr++, i++ ) {
		printf("\nAt Index %d Value %d", i, *ptr );
	}
}

//_________________________________________________________

void playWithArraysAndPointers2() {
	char greeting[20] 	= "Good Morning!";
	char *greetingAgain = "Good Morning!";
	
	for( char * ptr = greeting ; *ptr != '\0' ; ptr++ ) {
		printf("\nCharacter %c", *ptr );
	}

	for( ; *greetingAgain != '\0' ; greetingAgain++ ) {
		printf("\nCharacter %c", *greetingAgain );
	}
	// Array Name Is Constant Pointer 
	//		It Points To Starting Address Of Contiguous Memory
	// greeting++;
}

//_________________________________________________________

void playWithIfElse() {
	int x = -10;

	// if ( Expression )
	//		Expression Should Evaluate To Int Value
	//		If Expression Evaluates To NonZero Value Than It's True
	//		Otherwise Expression Evaluates To Zero Than It's False
	if ( x ) {
		printf("\nIf Block");
	} else {
		printf("\nElse Block");
	}
}

//_________________________________________________________


// Write Following sum Function Code In C
//		x And y Are Valid int Value
// 		Which Will Return Valid Arithmetic sum
//		Otherwise Print Can't Calculate sum For Given Values

// int sum(int x, int y)

// BAD CODE
int sum(int x, int y) {
	return x + y;
}

void playWithSum() {
	int x = 89989898898;
	int y = 1;

	int result = sum( x, y );
	printf("\n Result : %d", result );

	printf("\n INT_MAX :%d INT_MIN: %d", INT_MAX, INT_MIN);

	x = 2147483647;
	y = 2;
	result = sum( x, y );
	printf("\n Result : %d", result );

	// int k = sum(x, y);

	// int a[10] = {10, 20, 30, 40, 50, 60, 70, 80, 90, 00 };
	// for(  ; k < 10 ; k++) {
	// 	printf(" %d ", a[k]);
	// }
}


//_________________________________________________________

// Always False
// a + b > INT_MAX || a + b < INT_MIN

// Always True
// INT_MIN <= a, b <= INT_MAX
// INT_MIN <= a + b <= INT_MAX

signed int summation( signed int a, signed int b ) {
	signed int sum = 0;

	if( ( ( b > 0 ) && ( a > ( INT_MAX - b ) ) )  ||
		( ( b < 0 ) && ( a < ( INT_MIN - b ) ) ) ) {
		printf("Cann't Calculate Sum");
	} else {
		sum = a  +  b;
		return sum;
	}
}

//_________________________________________________________

enum Weekday { Sunday, Monday, Tuesday, Wednesday, Thursday, Friday, Saturday };

void playWithEnums() {
	enum Weekday someDay = Sunday;
	printf("\n%d", someDay);
	someDay = Monday;
	printf("\n%d", someDay);

	int someAnotherDay = Sunday;
	printf("\n%d", someAnotherDay);	

	enum Weekday someDayAgain = 9000;	
	printf("\n%d", someDayAgain);
}

//_________________________________________________________

void playWithOperatorsPrecedence() {
	int a[] = { 10, 20, 30, 40, 50 };

	int *ptr = a;

	printf("\n Result : %d", *ptr++ ); // Read The Value *ptr and than ptr++
	printf("\n Result : %d", *ptr );
}

//_________________________________________________________


void changeArray( int a[], int arraySize ) {
	for ( int i = 0 ; i < arraySize ; i++ ) {
		a[i] = 777;
	}
}

void playWithChangeArray() {
	int arraySize = 5;
	int a[5] = { 10, 20, 30, 40, 50 };

	printf("\nArray Elements Before changeArray Call: ");
	for ( int i = 0 ; i < arraySize ; i++ ) {
		printf(" %d ", a[i] );
	}

	changeArray( a, arraySize);
	printf("\nArray Elements After changeArray Call: ");
	for ( int i = 0 ; i < arraySize ; i++ ) {
		printf(" %d ", a[i] );
	}
}


//_________________________________________________________
//_________________________________________________________
//_________________________________________________________
//_________________________________________________________


int main() {
	printf("\n\nFunction : playWithVariables");
	playWithVariables();

	printf("\n\nFunction : playWithSizeof");
	playWithSizeof();

	printf("\n\nFunction : playWithPointers");
	playWithPointers();

	printf("\n\nFunction : playWithForLoopScope");
	playWithForLoopScope();

	printf("\n\nFunction : playWithArrays");
	playWithArrays();

	printf("\n\nFunction : playWithArraysAndPointers0");
	playWithArraysAndPointers0();

	printf("\n\nFunction : playWithArraysAndPointers1");
	playWithArraysAndPointers1();

	printf("\n\nFunction : playWithArraysAndPointers2");
	playWithArraysAndPointers2();

	printf("\n\nFunction : playWithIfElse");
	playWithIfElse();

	printf("\n\nFunction : playWithSum");
	playWithSum();

	printf("\n\nFunction : playWithEnums");
	playWithEnums();

	printf("\n\nFunction : playWithOperatorsPrecedence");
	playWithOperatorsPrecedence();

	printf("\n\nFunction : playWithChangeArray");
	playWithChangeArray();

	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");

	return 0;
}

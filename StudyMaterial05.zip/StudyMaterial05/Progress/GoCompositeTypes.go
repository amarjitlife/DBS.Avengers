
package main 

import (
	"fmt"
	"math/rand"
	"strings"
)

func playWithArrays() {
	// Initialised To Zero Of Type int
	var a [3]int

	for index, value := range a {
		fmt.Printf("\nAt Index : %d, Value : %d", index, value)
	}
	fmt.Println( a[0] )
	fmt.Println( a[1] )
	fmt.Println( a[2] )
	// Compilation Error
	// invalid argument: array index 3 out of bounds [0:3]
	// fmt.Println( a[3] )
	fmt.Println( a[ len(a) - 1 ] )
	for _, value := range a {
		fmt.Println( value )
	}

	var q [5]int = [5]int { 10, 20, 30, 40, 50 }
	var r [5]int = [5]int { 10, 20, 30 }

	fmt.Println("\nArray Length: ", len( q ) )
	for index, value := range q {
		fmt.Printf("\nAt Index : %d, Value : %d", index, value)
	}

	fmt.Println("\nArray Length: ", len( r ) )
	for index, value := range r {
		fmt.Printf("\nAt Index : %d, Value : %d", index, value)
	}

	s := [...]int{ 10, 20, 30, 111 }
	fmt.Println("\nArray Length: ", len( s ) )
	for index, value := range s {
		fmt.Printf("\nAt Index : %d, Value : %d", index, value)
	}

	some := [3]int{ 100, 200, 300 }
	fmt.Println("\nArray Length: ", len( some ) )
	fmt.Printf("\nData Type: %T", some )

	someAgain := [...]int{ 99 : -1  }
	fmt.Println("\nArray Length: ", len( someAgain ) )
	fmt.Printf("\nData Type: %T", someAgain )

	fmt.Println()
	for index, value := range someAgain {
		fmt.Printf(" Index : %d, Value : %d ###", index, value)
	}

	fmt.Println()
	fmt.Println( q )
	fmt.Println( r )
	fmt.Println( s )
	fmt.Println( some )
	fmt.Println( someAgain )

	aa := [2]int { 10, 20 }
	bb := [...]int {10, 20 }
	cc := [2]int { 10, 30 }

	fmt.Println( aa == bb, aa == cc, bb == cc )

	// Compilation Error
	// invalid operation: cc == dd (mismatched types [2]int and [3]int)
	// dd := [3]int { 10, 30 }
	// fmt.Println( cc == dd )
}

//_______________________________________________

func playWithBitwiseOperators() {
	var x = 10
	var y = 99
	
	fmt.Printf("\n%b", x)
	fmt.Printf("\n%b", y)

	fmt.Printf("\n%b", x | y )
	fmt.Printf("\n%b", x & y )
	fmt.Printf("\n%b", x ^ y )
}

//_______________________________________________

// Given operands a, b
// AND(a, b) = 1; only if a = b = 1
//                else = 0

func playWithBitwiseAndOperator() {
    var x uint8 = 0xAC    // x = 10101100

	// x = 		1010 1100
	//	   & 	11110000

	fmt.Printf("\n%b", x)
    x &= 0xF0             // x = 10100000
	fmt.Printf("\n%b", x)
}

func playWithBitwiseAndOperatorUseCase() {
    for x := 0; x < 100; x++ {
        num := rand.Int()
        if num & 1 == 1 {
            fmt.Printf("%d is odd\n", num)
        } else {
            fmt.Printf("%d is even\n", num)
        }
    }
}

// Given operands a, b
// OR(a, b) = 1; when a = 1 or b = 1
//               else = 0 

func playWithBitwiseOrOperator() {
    var x uint8 = 10 		// 		00001010
    x |= 196  				// | 	11000100
    fmt.Printf("\n%b", x)   // 		11001110
}

// Given operands a, b
// XOR(a, b) = 1; only if a != b
//      else = 0

func playWithBitwiseXorOperator0() {
    var x uint16 = 0xCEFF	// 	  1100 1110 1111 1111
    x ^= 0xFF00 			// 	^ 1111 1111 0000 0000

    fmt.Printf("\n%b", x)   // 0011 0001 1111 1111
}

func playWithBitwiseXorOperator1() {
    var x byte = 0x0F  			//0000 1111
    fmt.Printf("%08b\n", x) 	//0000 1111	
    fmt.Printf("%08b\n", ^x) 	//1111 0000

    // In Go ^x = 1 ^ x which reverses Bit In x
}

// Given operands a, b
// AND_NOT(a, b) = AND(a, NOT(b))
	
	// AND_NOT(a, 1) = 0; clears a
	// AND_NOT(a, 0) = a; 

func playWithBitwiseAndNotOperator() {
    var x byte = 0xAB         	// 	1010 1011
     
     fmt.Printf("%08b\n", x)    // 		1010 1011
     x &^= 0x0F                 //&^ 	0000 1111   
     fmt.Printf("%08b\n", x)    //		1010 0000
}


//_______________________________________________

type Flags uint

const (
	FlagUp Flags 	= 1 << iota
	FlagBroadcast
	FlagLoopback
	FlagPointToPoint
	FlagMulticast
)

func IsUp(v Flags) bool 	{ return v & FlagUp == FlagUp }
func TurnDown(v *Flags)		{ *v &^= FlagUp } // &^ (AND NOT) This Will Clear Bit
func SetBroadcast(v *Flags) { *v |= FlagBroadcast }
func IsCast(v Flags) bool 	{ return v & (FlagBroadcast | FlagMulticast ) != 0 }

func playWithFlags() {
	var v Flags = FlagMulticast | FlagUp

	fmt.Printf("%b %t\n", v, IsUp( v ) )
	TurnDown( &v )
	fmt.Printf("%b %t\n", v, IsUp( v ) )

	SetBroadcast( &v )
	fmt.Printf("%b %t\n", v, IsUp( v ) )
	fmt.Printf("%b %t\n", v, IsCast( v ) )
}

// Operator precedence
// Unary operators have the highest precedence. 
// As the ++ and -- operators form statements, not expressions, 
// they fall outside the operator hierarchy. 
// As a consequence, statement *p++ is the same as (*p)++.

// There are five precedence levels for binary operators. 
// Multiplication operators bind strongest, 
// followed by addition operators, comparison operators, 
// && (logical AND), and finally || (logical OR):

// Precedence    	Operators
//     5             *  /  %  <<  >>  &  &^
//     4             +  -  |  ^
//     3             ==  !=  <  <=  >  >=
//     2             &&
//     1             ||

// Binary operators of the same precedence associate from 
// left to right. For instance, x / y * z is the same as (x / y) * z.

//NOTE : Precedence Order and Rules Are Not Same In Go and C
// 		https://go.dev/ref/spec#Operators
// 		https://en.cppreference.com/w/c/language/operator_precedence

//_______________________________________________

const (
	UPPER = 1 // upper case
	LOWER = 2 // lower case
	CAP   = 4 // capitalizes
	REV   = 8 // reverses
)

func processString(str string, conf byte) string {
    // reverse string
	rev := func(s string) string {
		runes := []rune(s)
		n := len(runes)
		for i := 0; i < n/2; i++ {
			runes[i], runes[n-1-i] = runes[n-1-i], runes[i]
		}
		return string(runes)
	}
	
	// query configs
	if (conf & UPPER) != 0 {
		str = strings.ToUpper(str)
	}
	if (conf & LOWER) != 0 {
		str = strings.ToLower(str)
	}
	if (conf & CAP) != 0 {
		str = strings.Title(str)
	}
	if (conf & REV) != 0 {
		str = rev(str)
	}
	return str
}

func playWithProcessString() {
	fmt.Println( processString("HELLO PEOPLE!", LOWER|REV|CAP) )
}

//_______________________________________________

// In C/C++/Java By Default:
//		Arrays Are Pass By Reference

// In Go By Default:
//		Arrays Are Pass By Value
//		Function Will By Default Creates Local Copy 
// 			Of The The Whole Arrayi.e. All It's Elements

func changeArray( a [5]int ) {
	for i, _ := range a {
		a[ i ] = 777;
	}
	fmt.Println( "Array Inside Function: ", a )
}

func changeArrayAgain( a *[5]int ) {
	for i, _ := range a {
		a[ i ] = 777;
	}
}

func playWithChangeArray() {
	var aa [5]int = [5]int { 10, 20, 30, 40, 50 }

	fmt.Println("Array Elements Before changeArray :", aa )
	changeArray( aa )
	fmt.Println("Array Elements After  changeArray :", aa )

	fmt.Println("Array Elements Before changeArrayAgain :", aa )
	changeArrayAgain( &aa )
	fmt.Println("Array Elements After  changeArrayAgain :", aa )
}

//_______________________________________________
//_______________________________________________
//_______________________________________________
//_______________________________________________


func main() {
	fmt.Println("\n\nFunction : playWithArrays")
	playWithArrays()

	fmt.Println("\n\nFunction : playWithBitwiseOperators")
	playWithBitwiseOperators()

	fmt.Println("\n\nFunction : playWithFlags")
	playWithFlags()

	fmt.Println("\n\nFunction : playWithChangeArray")
	playWithChangeArray()

	// fmt.Println("\n\nFunction : ")
	// fmt.Println("\n\nFunction : ")
	// fmt.Println("\n\nFunction : ")
	// fmt.Println("\n\nFunction : ")
	// fmt.Println("\n\nFunction : ")
	// fmt.Println("\n\nFunction : ")
	// fmt.Println("\n\nFunction : ")
	// fmt.Println("\n\nFunction : ")
	// fmt.Println("\n\nFunction : ")
	// fmt.Println("\n\nFunction : ")
}



_______________________________________________________

DAY 01 
_______________________________________________________

	ASSIGNMENT A1: READING AND THINKING ASSIGNMENT
		Read First 05 Chapters Thoroughly From Following Book
			The C Programming Language, 2nd Edition, 
				By Brian W. Kernigham and Dennis Ritchie

			Book Download Link:
				https://kremlin.cc/k&r.pdf

_______________________________________________________

DAY 02 
_______________________________________________________


	ASSIGNMENT A1: READING AND THINKING ASSIGNMENT
		NOTE >>> Read Thoroughly From Following Book

		Chapters 05 : Pointers And Arrays 
		Chapters 06 : Structures
			The C Programming Language, 2nd Edition, 
				By Brian W. Kernigham and Dennis Ritchie

			Book Download Link:
				https://kremlin.cc/k&r.pdf

_______________________________________________________

DAY 03 
_______________________________________________________


	ASSIGNMENT A1: READING AND THINKING ASSIGNMENT
		NOTE >>> Read Thoroughly From Following Book

		Chapters 05 : Pointers And Arrays [ REVISE ] 
		Chapters 06 : Structures [ COMPLETE ]
			The C Programming Language, 2nd Edition, 
				By Brian W. Kernigham and Dennis Ritchie

	ASSIGNMENT A2: REVISE AND PRACTICE Go Code Till What We Done

	CODING ASSIGNMENT A3 : Simulate Following Python Code In C
		
		>>> m = [10, 20, 30, 40, 50]
		>>> n = m
		>>> m
		[10, 20, 30, 40, 50]
		>>> n
		[10, 20, 30, 40, 50]
		>>> m[0] = 1000
		>>> m
		[1000, 20, 30, 40, 50]
		>>> n
		[1000, 20, 30, 40, 50]

	CODING ASSIGNMENT A4 : Simulate Following Python Code In C
		Without Using Any Library Function

		>>> m = [10, 20, 30, 40, 50]
		>>> import copy
		>>> n = copy.deepcopy( m )
		>>> n
		[10, 20, 30, 40, 50]
		>>> m[0] = 1000
		>>> m
		[1000, 20, 30, 40, 50]
		>>> n
		[10, 20, 30, 40, 50]

_______________________________________________________

DAY 04 
_______________________________________________________


ASSIGNMENT A1: Experiment and Practice Code Example

	1. Experiment Go Code Till Now Covered

	2. Experiment stings Package Functions
		- Read strings Documentation
			https://pkg.go.dev/strings

		- Experiment Following strings Examles
			https://www.golangprograms.com/golang/string-functions/


ASSIGNMENT A2: READING AND THINKING ASSIGNMENT
	NOTE >>> Read Thoroughly From Following Book

	Chapters 06 : Structures [ COMPLETE IT ]
		The C Programming Language, 2nd Edition, 
			By Brian W. Kernigham and Dennis Ritchie


_______________________________________________________

DAY 05 
_______________________________________________________





_______________________________________________________

DAY 06 
_______________________________________________________





_______________________________________________________

DAY 07 
_______________________________________________________





_______________________________________________________

DAY 08 
_______________________________________________________





_______________________________________________________

DAY 09 
_______________________________________________________





_______________________________________________________

DAY 10 
_______________________________________________________




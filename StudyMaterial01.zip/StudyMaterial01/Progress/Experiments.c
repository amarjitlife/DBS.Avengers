/*
// Compiling And Running C Code
	gcc Experiment.c -o experiment
	./experiment
*/

#include <stdio.h>

int playWithVariables() {
	int e;
	printf("\nValue of e : %d", e);
}

int main() {
	printf("\nFunction : playWithVariables");
	playWithVariables();

	// printf("\nFunction : ");
	// printf("\nFunction : ");
	// printf("\nFunction : ");
	// printf("\nFunction : ");
	// printf("\nFunction : ");
	// printf("\nFunction : ");
	// printf("\nFunction : ");
	// printf("\nFunction : ");
	// printf("\nFunction : ");
	// printf("\nFunction : ");
	// printf("\nFunction : ");
	// printf("\nFunction : ");
	// printf("\nFunction : ");
	// printf("\nFunction : ");
	// printf("\nFunction : ");
	// printf("\nFunction : ");
	// printf("\nFunction : ");
	// printf("\nFunction : ");
	// printf("\nFunction : ");
	// printf("\nFunction : ");

	return 0;
}
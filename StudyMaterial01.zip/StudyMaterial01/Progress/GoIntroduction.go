	
package main

import "fmt"
import "math"
import "time"

//_______________________________________________

func helloWorld() {
	fmt.Println("Hello World!!!")
}

//_______________________________________________

func playWithValues() {
	fmt.Println("Go" + "Language")
	fmt.Println( "10+ 20", 10 + 20 )
	fmt.Println( "10.9     + 20.9", 10.9 + 20.9 )

	fmt.Println( true && false )
	fmt.Println( true || false )
	fmt.Println( !true )
	fmt.Println( !false )
}

//_______________________________________________

func playWithVariable() {
	// Creating a Variable With String Type Initial Value
	// Implicitly Inferred Type Of a Variable Is string
	var a = "Good Afternoon!"
	fmt.Println( a )

	// Explicitly Specifying Type of b And c As int
	var b, c int = 1, 2 
	fmt.Println( b, c )

	// Implicitly Inferred Type From RHS Value
	//		Hence b Type Will Be Boolean
	var d = true
	fmt.Println( d )

	// Explicitly Specifying Type of e As int
	//		Default Value For int Type Will Be 0
	var e int 
	fmt.Println( e )

	// f Will Be Created Immutable Value Of Type string
	f := "Apples and Manoges "
	fmt.Println( f )
}

//_______________________________________________

const s string = "Some Constant Value"

func playWithConstants() {
	fmt.Println( s )

	const dbsStartingSalary = 890000
	fmt.Println( dbsStartingSalary )

	const count = 3e20 / dbsStartingSalary
	fmt.Println( count )

	fmt.Println( int64( dbsStartingSalary ) )
	fmt.Println( math.Sin( math.Pi / 2 ) )

	// Following Will Give Compilation Errors
	// const Are Immutable In Nature
	// s = "Something else"
	// dbsStartingSalary = dbsStartingSalary + 200000
}

//_______________________________________________

func playWithForLoop() {	
	// Short Hand Notation
	i := 1
	for i <= 3 {
		fmt.Println( i )
		i++
	}

	for j := 7 ; j <= 11 ; j++ {
		fmt.Println( j )
	} 

	// Infinite Loop Because Default Value Of Condition Is true
	// for { 
	// 	fmt.Println("Loop")
	// }

	for n := 0 ; n <= 5 ; n++ {
		if n % 2 == 0 {
			continue
		}
		fmt.Println( n )
	}
}

//_______________________________________________

func playWithIfElse() {
	if 7 % 2 == 0 {
		fmt.Println("7 Divisible By 2")
	} else {
		fmt.Println("7 Not Divisible By 2")
	}

	if  8 % 4 == 0 {
		fmt.Println("8 Divisible By 4")
	}

	if num := 9 ; num < 0 {
		fmt.Println("Number Is Negative")
	} else if num == 0 {
		fmt.Println("Number Is Zero")		
	} else {
		fmt.Println("Number Is Positive")		
	}
}

//_______________________________________________

func playWithSwitch() {
	i := 2

	fmt.Println("Integer's English Vocal Values")
	// For Each case
	// break Is Implicit In Go Laguage
	switch i {
	// expression i == 0
	case 0 :
		fmt.Println( "Zero" )
	case 1 :
		fmt.Println( "One" )
	case 2 :
		fmt.Println( "Two" )
	case 3 :
		fmt.Println( "Three" )
	}

	switch time.Now().Weekday() {
	case time.Saturday, time.Sunday:
		fmt.Println("Happy Weekends!!! Lets Enjoy!!!")
	default:
		fmt.Println("Work Weekdays!!! Lets Work!!!")		
	}

	t := time.Now()
	switch {
	case t.Hour() < 12: 
		fmt.Println("Before Noon...")		
	default:
		fmt.Println("After Noon...")
	}
}

//_______________________________________________
//_______________________________________________
//_______________________________________________
//_______________________________________________
//_______________________________________________
//_______________________________________________
//_______________________________________________
//_______________________________________________
//_______________________________________________

func main() {
	fmt.Println("\nFunction : helloWorld")
	helloWorld()

	fmt.Println("\nFunction :playWithValues")
	playWithValues()
	
	fmt.Println("\nFunction : playWithConstants")
	playWithConstants()

	fmt.Println("\nFunction : playWithForLoop")
	playWithForLoop()

	fmt.Println("\nFunction : playWithIfElse")
	playWithIfElse()

	fmt.Println("\nFunction : playWithSwitch")
	playWithSwitch()

	// fmt.Println("\nFunction : ")
	// fmt.Println("\nFunction : ")
	// fmt.Println("\nFunction : ")
	// fmt.Println("\nFunction : ")
	// fmt.Println("\nFunction : ")
	// fmt.Println("\nFunction : ")
	// fmt.Println("\nFunction : ")
	// fmt.Println("\nFunction : ")
	// fmt.Println("\nFunction : ")
	// fmt.Println("\nFunction : ")
	// fmt.Println("\nFunction : ")
	// fmt.Println("\nFunction : ")
	// fmt.Println("\nFunction : ")
	// fmt.Println("\nFunction : ")
}

package main 

import (
	"fmt"
	"flag"
	"strings"
)

const boilingPointF = 212.0

func playWithBoilingPoint0() {
	var f = boilingPointF
	var c = ( f - 32 ) * 5 / 9
	fmt.Printf("Boiling Point = %g℉ Or %g℃", f, c)
}


//_______________________________________________


func playWithBoilingPoint1() {
	// Local boildingPointF Takes Precedence Over Global Identifier
	//		With Same Name
	//						Similar To Tuple Unpacking
	const freezingPointF, boilingPointF = 32.0, 212.0

	fmt.Printf("Freezing Point = %g℉ Or %g℃", 
		freezingPointF, fToC( freezingPointF ) )
	fmt.Printf("\nBoiling Point = %g℉ Or %g℃", 
		boilingPointF, fToC( boilingPointF ) )
}

func fToC(f float64) float64 {
	return ( f - 32 ) * 5 / 9
}

//_______________________________________________

// flag Package

func playWithFlag() {
	var n 		  = flag.Bool("n", false, "Omits trailing newline")
	var seperator = flag.String("s", " ", "Specify seperator")

	flag.Parse()

	fmt.Print( strings.Join( flag.Args(), *seperator ) )

	if !*n {
		fmt.Println()
	}
}


//_______________________________________________


func playWithDataTypes() {

	// To Create Safe Code
	//		Go Will Intiatialse Variables To Default Values
	//			Zeros Of Type

	// 	Zero For bool Type Is false
	//	Zero For int Type Is 0
	//	Zero For float32 And float64 Type Is 0.0
	//	Zero For string Type Is ""
	var c, python, java bool
	var i int 
	var ff float32
	var dd float64

	// Mutable Values Initialised From RHS
	var ii, jj int = 10, 20

	var iii, jjj = 100, 200

	var iiii, jjjj int

	// Type Inferrencing and Type Binding
	//	1. Type Inferrencing From RHS Value
	//	2. Inferred Type Is Binded With LHS Identifier
	k := 3

	some, some1, something := true, false, "Good!"

	fmt.Println(c, python, java, i)
	fmt.Println( ff, dd )
	fmt.Printf( "ff = %f dd = %f\n", ff, dd )

	fmt.Println( ii, jj )
	fmt.Println( iii, jjj )
	fmt.Println( iiii, jjjj )

	fmt.Println( k, some, some1, something )

	// var someone
}


//_______________________________________________


type Celsius 	float64
type Fahrenheit float64

func FToC(f Fahrenheit) Celsius { return Celsius( (f - 32) * 5/9 )   }
func CToF(c Celsius) Fahrenheit { return Fahrenheit( (c * 9/5) + 32 )}

const (
	BoilingC		Celsius 	= 100.0
	FreezingC 		Celsius 	= 0.0
	AbsoluteZeroC 	Celsius 	= -273.15
	FreezingF 		Fahrenheit 	= 0.0
)

func playWithConstants() {
	fmt.Printf("\n %g", BoilingC + FreezingC )

	boilingF := CToF( BoilingC )

	fmt.Printf("\n %g", boilingF - CToF( FreezingC) )
	fmt.Printf("\n %g", boilingF)

	var something float64 = 100.100
	fmt.Printf("\n %g", something)

	//		Go Language Follows Type Strictness
	// boilingF + something
	// BoilingC + something
	// BoilingC + FreezingF
}


//_______________________________________________


func playWithFormatSpecifiers() {
	c := FToC( 100.0 )

	fmt.Println( c ) 		//  100
	fmt.Printf("\n %v", c)  //  100
	fmt.Printf("\n %f", c)  //  100.000000
	fmt.Printf("\n %g", c)  //  100
	fmt.Printf("\n %e", c)  //  1.000000e+02
	fmt.Printf("\n %G", c)  //  100
	fmt.Printf("\n %E", c)  //  1.000000E+02\

	// Extend This Code To Experiment With 
	//		All Printf Format Specifiers

	cc := FToC( 300.0 )

	fmt.Println( cc ) 			
	fmt.Printf("\n %v", cc)  
	fmt.Printf("\n %f", cc)  
	fmt.Printf("\n %g", cc)  
	fmt.Printf("\n %e", cc)  
	fmt.Printf("\n %G", cc)  
	fmt.Printf("\n %E", cc)  
}


//_______________________________________________

func playWithIfElse() {
	var x = -10
	//Compilation Error: non-boolean condition in if statement
	// if x {

	// if Expression
	//		Expresion Must Evaluate To Boolean Type/Value
	if x == -10  {		
		fmt.Println("If Block")
	} else {
		fmt.Println("Else Block")
	}
}

func btoi( b bool ) int {
	if b { return 1 }
	return 0
}

func itob( i int ) bool { return i != 0 }

func playWithIfElseAgain() {
	var x = -10

	if itob( x ) {		
		fmt.Println("If Block")
	} else {
		fmt.Println("Else Block")
	}
}

//_______________________________________________
//_______________________________________________
//_______________________________________________
//_______________________________________________
//_______________________________________________


func main() {
	fmt.Println("\n\nFunction : playWithBoilingPoint0")
	playWithBoilingPoint0()

	fmt.Println("\n\nFunction : playWithBoilingPoint1")
	playWithBoilingPoint1()

	fmt.Println("\n\nFunction : playWithFlag")
	playWithFlag()

	fmt.Println("\n\nFunction : playWithDataTypes")
	playWithDataTypes()

	fmt.Println("\n\nFunction : playWithConstants")
	playWithConstants()

	fmt.Println("\n\nFunction : playWithFormatSpecifiers")
	playWithFormatSpecifiers()

	fmt.Println("\n\nFunction : playWithIfElse")
	playWithIfElse()

	fmt.Println("\n\nFunction : playWithIfElseAgain")
	playWithIfElseAgain()

	// fmt.Println("\n\nFunction : ")
	// fmt.Println("\n\nFunction : ")
	// fmt.Println("\n\nFunction : ")
	// fmt.Println("\n\nFunction : ")
	// fmt.Println("\n\nFunction : ")
	// fmt.Println("\n\nFunction : ")
	// fmt.Println("\n\nFunction : ")
	// fmt.Println("\n\nFunction : ")
	// fmt.Println("\n\nFunction : ")
	// fmt.Println("\n\nFunction : ")
}


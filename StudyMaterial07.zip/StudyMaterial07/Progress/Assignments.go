
_______________________________________________________

DAY 01 
_______________________________________________________

	ASSIGNMENT A1: READING AND THINKING ASSIGNMENT
		Read First 05 Chapters Thoroughly From Following Book
			The C Programming Language, 2nd Edition, 
				By Brian W. Kernigham and Dennis Ritchie

			Book Download Link:
				https://kremlin.cc/k&r.pdf

_______________________________________________________

DAY 02 
_______________________________________________________


	ASSIGNMENT A1: READING AND THINKING ASSIGNMENT
		NOTE >>> Read Thoroughly From Following Book

		Chapters 05 : Pointers And Arrays 
		Chapters 06 : Structures
			The C Programming Language, 2nd Edition, 
				By Brian W. Kernigham and Dennis Ritchie

			Book Download Link:
				https://kremlin.cc/k&r.pdf

_______________________________________________________

DAY 03 
_______________________________________________________


	ASSIGNMENT A1: READING AND THINKING ASSIGNMENT
		NOTE >>> Read Thoroughly From Following Book

		Chapters 05 : Pointers And Arrays [ REVISE ] 
		Chapters 06 : Structures [ COMPLETE ]
			The C Programming Language, 2nd Edition, 
				By Brian W. Kernigham and Dennis Ritchie

	ASSIGNMENT A2: REVISE AND PRACTICE Go Code Till What We Done

	CODING ASSIGNMENT A3 : Simulate Following Python Code In C
		
		>>> m = [10, 20, 30, 40, 50]
		>>> n = m
		>>> m
		[10, 20, 30, 40, 50]
		>>> n
		[10, 20, 30, 40, 50]
		>>> m[0] = 1000
		>>> m
		[1000, 20, 30, 40, 50]
		>>> n
		[1000, 20, 30, 40, 50]

	CODING ASSIGNMENT A4 : Simulate Following Python Code In C
		Without Using Any Library Function

		>>> m = [10, 20, 30, 40, 50]
		>>> import copy
		>>> n = copy.deepcopy( m )
		>>> n
		[10, 20, 30, 40, 50]
		>>> m[0] = 1000
		>>> m
		[1000, 20, 30, 40, 50]
		>>> n
		[10, 20, 30, 40, 50]

_______________________________________________________

DAY 04 
_______________________________________________________


ASSIGNMENT A1: Experiment and Practice Code Example

	1. Experiment Go Code Till Now Covered

	2. Experiment stings Package Functions
		- Read strings Documentation
			https://pkg.go.dev/strings

		- Experiment Following strings Examles
			https://www.golangprograms.com/golang/string-functions/


ASSIGNMENT A2: READING AND THINKING ASSIGNMENT
	NOTE >>> Read Thoroughly From Following Book

	Chapters 06 : Structures [ COMPLETE IT ]
		The C Programming Language, 2nd Edition, 
			By Brian W. Kernigham and Dennis Ritchie


_______________________________________________________

DAY 05 
_______________________________________________________


ASSIGNMENT A1: READING AND THINKING ASSIGNMENT
	NOTE >>> Read Thoroughly From Following Book

	Read All Chapters
		The C Programming Language, 2nd Edition, 
			By Brian W. Kernigham and Dennis Ritchie


_______________________________________________________

DAY 06 
_______________________________________________________


ASSIGNMENT A1: READING AND CODING ASSIGNMENT
	NOTE >>> Read Thoroughly From Following Book

	01 To 03 Chapters : First 50 Pages
		Learning Go, Jon Bodner, Orielly Publication
		
		Book Link : https://b-ok.asia/book/17010861/773348

ASSIGNMENT A2: Multidimentional Arrays In C and Go

_______________________________________________________

DAY 07 
_______________________________________________________


ASSIGNMENT A1: READ THROUGHLY AND CODING ASSIGNMENT [ MUST ]

	CHAPTERS : 01 To 04 [ First 80 Pages ]
		Learning Go, Jon Bodner, Orielly Publication
		
		Book Link : https://b-ok.asia/book/17010861/773348

ASSIGNMENT A2: GO CODING ASSIGNMENTS [ MUST ]

	01. Simulate Stack and Stack Operations Using Slices
	02. Remove Duplicate Words From User Input
			Implement This Using Multiple Ways
	03. Simulate Tower Of Hanoi
	04. GCD Using Recursion
	05. 	2 Dimenstional Matix Multiplication
	06. Print Two Numbers From Array That Occurs Odd Numbers Of Times
	07. Anagrams Using Slices
	08. Calculate Frequency Of Numbers In Numbers List
	09. Move Snake Of Numbers 9876543210 In Two Dimentional Square Array. 
		Snakes Enters In TopLeft Corner and Spiral In Square and Keep Going Towards
		Center.
	10. Implement Sparse Matrix To Store Variable Length Names
	11. Largest Sum Contiguous Subarray [ Kadane ]
	12. Implement Binary Search Algorithm
	13. Find In Array List Of Missing Integer
	14. Search Logest Positive Sub Sequence From List Of Numbers
	15. Create Tree Mirror
	16. Generate Postfix and Prefix Notation For A Infix Expression

_______________________________________________________

DAY 08 
_______________________________________________________





_______________________________________________________

DAY 09 
_______________________________________________________





_______________________________________________________

DAY 10 
_______________________________________________________




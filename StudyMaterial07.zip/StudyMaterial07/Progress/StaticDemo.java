// Java program to Demonstrate How to
// Implement Static and Non-static Classes

class StaticExample {
	// Input string
	public static String message = "GeeksForGeeks";
	public String hello = "Hello World!";

	public void sayHello() { System.out.println( hello ); }
	public static void printMessage() { System.out.println( message );	}
}

class StaticDemo {
	public static void main(String args[]) {
		StaticExample staticExample = new StaticExample();
		
		staticExample.sayHello();
		System.out.println( staticExample.hello );

		StaticExample.printMessage();
		System.out.println( StaticExample.message );

		StaticExample.message = "Ding Dong";
		StaticExample staticExampleAgain = new StaticExample();
		
		staticExampleAgain.sayHello();
		System.out.println( staticExampleAgain.hello );

		StaticExample.printMessage();
		System.out.println( StaticExample.message );
	}
}

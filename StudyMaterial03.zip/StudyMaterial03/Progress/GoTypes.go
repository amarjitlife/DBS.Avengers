
package main

import "fmt"

// In Go Data Types

// int, bool, string, float32, float64

	// 	Zero For bool Type Is false
	//	Zero For int Type Is 0
	//	Zero For float32 And float64 Type Is 0.0
	//	Zero For string Type Is ""


// WHAT IS DATA TYPE???

// 		What Type Of Operation You Can Perform?
//		Set Of Values


//_______________________________________________

func playWithComplexTypes() {
	var x complex128 = complex(1, 2) // 1 + 2i
	var y complex128 = complex(3, 4) // 3 + 4i

	fmt.Println( x )
	fmt.Println( y )
	fmt.Println( x + y )
	fmt.Println( x - y )
	fmt.Println( x * y )
	fmt.Println( real( x ) )
	fmt.Println( imag( x ) )

	xx := 1 + 2i
	yy := 3 + 4i

	fmt.Println( xx )
	fmt.Println( yy)
	fmt.Println( xx + yy )
	fmt.Println( xx - yy )
	fmt.Println( xx * yy )
	fmt.Println( real( yy ) )
	fmt.Println( imag( yy ) )

	var aa complex64 = complex( 10, 20 )
	var bb complex64 = complex( 10, 20 )

	fmt.Println( aa )
	fmt.Println( bb)
	fmt.Println( aa + bb )
}

//_______________________________________________

func basename( s string ) string {
	for i := len(s) - 1 ; i >= 0 ; i-- {
		if s[i] == '/' {
			s = s[ i + 1 :  ]
			break
		}
	}

	for i := len(s) - 1 ; i >= 0 ; i-- {
		if s[i] == '.' {
			s = s[  : i ]
			break
		}
	}
	return s 
}

func playWithBaseName() {
	fmt.Println( basename("/media/WorkArea/Trainings/DBSTech/Progress"))
	fmt.Println( basename( "/media/WorkArea/Trainings/DBSTech/Progress/GoIntroduction.go" ))
}


//_______________________________________________
//_______________________________________________
//_______________________________________________


func main() {
	fmt.Println("\n\nFunction : playWithComplexTypes")
	playWithComplexTypes()

	fmt.Println("\n\nFunction : playWithBaseName")
	playWithBaseName()

	// fmt.Println("\n\nFunction : ")
	// fmt.Println("\n\nFunction : ")
	// fmt.Println("\n\nFunction : ")
	// fmt.Println("\n\nFunction : ")
	// fmt.Println("\n\nFunction : ")
	// fmt.Println("\n\nFunction : ")
	// fmt.Println("\n\nFunction : ")
	// fmt.Println("\n\nFunction : ")
	// fmt.Println("\n\nFunction : ")
	// fmt.Println("\n\nFunction : ")
	// fmt.Println("\n\nFunction : ")
	// fmt.Println("\n\nFunction : ")
	// fmt.Println("\n\nFunction : ")
	// fmt.Println("\n\nFunction : ")
	// fmt.Println("\n\nFunction : ")
	// fmt.Println("\n\nFunction : ")
	// fmt.Println("\n\nFunction : ")
	// fmt.Println("\n\nFunction : ")
}


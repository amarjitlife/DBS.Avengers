/*
// Compiling And Running C Code
	gcc Experiment.c -o experiment
	./experiment
*/

#include <stdio.h>

int globalVariable = 0;

int playWithVariables() {
	int e;
	printf("\nValue of e : %d", e);
}

//_________________________________________________________


void playWithSizeof() {
	char 	cc = 'A';
	int 	ii = 20;
	float 	ff = 30.9;
	double 	dd = 100.0;

	printf("\n Size char   type: %ld", sizeof( cc ) );
	printf("\n Size int    type: %ld", sizeof( ii ) );
	printf("\n Size float  type: %ld", sizeof( ff ) );
	printf("\n Size double type: %ld", sizeof( dd ) );

	char 	* cptr = &cc;
	int  	* iptr = &ii;
	float 	* fptr = &ff;
	double  * dptr = &dd;

	printf("\n Size char   * type: %ld", sizeof( cptr ) );
	printf("\n Size int    * type: %ld", sizeof( iptr ) );
	printf("\n Size float  * type: %ld", sizeof( fptr ) );
	printf("\n Size double * type: %ld", sizeof( dptr ) );
}


//_________________________________________________________


void playWithPointers() {
	int a = 20;

	int 	  *address1 	= &a;
	int 	 **address2 	= &address1;
	int 	***address3 	= &address2;
	int    ****address4 	= &address3;

	printf("\n %ld %ld", address4, *address4 );
	printf("\n %ld %ld", address3, *address3 );
	printf("\n %ld %ld", address2, *address2 );
	printf("\n %ld %ld", address1, *address1 );

	printf("\n %ld", **address4 );
	printf("\n %ld", **address3 );
	printf("\n %ld", **address2 );

	printf("\n %ld", ***address3 );
	printf("\n %ld", **address2 );
	printf("\n %ld", *address1 );
}


//_________________________________________________________
//_________________________________________________________
//_________________________________________________________
//_________________________________________________________
//_________________________________________________________
//_________________________________________________________
//_________________________________________________________
//_________________________________________________________


int main() {
	printf("\n\nFunction : playWithVariables");
	playWithVariables();

	printf("\n\nFunction : playWithSizeof");
	playWithSizeof();

	printf("\n\nFunction : playWithPointers");
	playWithPointers();

	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");

	return 0;
}

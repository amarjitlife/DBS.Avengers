
/*
// Run Directly Go File
go run Hello.go

// Build And Than Run Go File:

go build Hello.go 
./Hello

*/

package main 

import "fmt"

func main() {
	fmt.Println("Hello World!!!")
}



#include <stdio.h>
#include <stdlib.h>

typedef struct item_type {
	int data;
} Item;

typedef struct node_type {
	Item item;
	struct node_type * left;
	struct node_type * right;
	 // Node * left;
	 // Node * right;
} Node;

typedef struct node_type_design2 {
	Item item;
	struct node_type * parent;
	struct node_type * left;
	struct node_type * right;
	 // Node * left;
	 // Node * right;
} NodeDesign2;

Node * createNode( Item item );
void addNode( Node * root, Node *newNode );
void traverseBinarySearchTree( Node * root );
void processNode( Node * node );

Node * createNode( Item item ) {
	Node * node = ( Node * ) malloc( sizeof( Node ) ) ;
	// Initialise Node
	node -> item 	= item; 
	node -> left 	= NULL;
	node -> right 	= NULL;

	return node;
}

void addNode( Node * root, Node *newNode ) {
	if ( root == NULL ) {
		printf("\n Create Empty Tree First with Root Node...");		
		return;
	}

	int data = newNode -> item.data;	
	Node * nextNode = root;
	Node * parentNode = NULL;
	// Traverse Till End
	while ( nextNode != NULL ) {
		parentNode = nextNode;

		if ( data <   nextNode -> item.data ) 
			nextNode = nextNode -> left;
		else {
			nextNode = nextNode -> right;
		}
	}

	if ( data < parentNode -> item.data ) {
		parentNode -> left = newNode;
	} else {
		parentNode -> right = newNode;
	}
}

Node * createBinarySearchTree() {
	Item item;
	Node *node;

	item.data = 10;
	Node * root = createNode( item );
	
	item.data = 6;
	node = createNode( item );
	addNode( root, node );

	item.data = 4;
	node = createNode( item );
	addNode( root, node );

	item.data = 8;
	node = createNode( item );
	addNode( root, node );

	item.data = 20;
	node = createNode( item );
	addNode( root, node );

	item.data = 15;
	node = createNode( item );
	addNode( root, node );

	item.data = 25;
	node = createNode( item );
	addNode( root, node );

	// printf("\n %d ", head -> item.data );
	return root;
}

void traverseBinarySearchTree( Node * root ) {
	if ( root == NULL ) return;

	traverseBinarySearchTree( root -> left );
	processNode( root );
	traverseBinarySearchTree( root -> right );	
}

void processNode( Node * node ) {
	printf("\n Node : %d", node -> item.data );
}

int main() {
	Node * tree = createBinarySearchTree();
	traverseBinarySearchTree( tree );
}

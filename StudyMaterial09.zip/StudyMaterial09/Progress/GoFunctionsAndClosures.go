
package main

import (
	"fmt"
	// "math"
)

//_______________________________________________

func division( dividend, divisor int ) ( int, int ) {
	if divisor != 0 {
		quotient := dividend / divisor
		remainder := dividend % divisor

		return quotient, remainder
	} else {
		fmt.Println("Error: Division By Zero....`")
	}
	return 0, 0
}

											// Labeled/Named Tuple
func divisionAgain( dividend, divisor int ) ( quotient int, remainder int ) {
	if divisor != 0 {
		quotient := dividend / divisor
		remainder := dividend % divisor
		return quotient, remainder
	} else {
		fmt.Println("Error: Division By Zero....`")
	}
	return 0, 0
}

//_______________________________________________

// calculator Is Polymorphic
func calculator(x, y int, operation func(int, int) int ) int {
	return operation( x, y )
}

func multiplication( x, y int ) int { return x * y }

func doSomething( task int, time float32 ) { 
	fmt.Printf("\nDoing Task %d In Time %f\n", task, time )
}

func playWithFunctionsAndClosures() {
	var x, y = 30, 10 
	var result int 

	var something = doSomething
	something( 100, 99.9 )

	// Closure/Lamdba Expression
	addition 		:= func( x, y int ) int { return x + y }
	substraction 	:= func( x, y int ) int { return x - y }

	result = addition( x , y )
	fmt.Println("Result : ", result )

	result = substraction( x , y )
	fmt.Println("Result : ", result )	

	result = calculator( x , y, addition )
	fmt.Println("Result : ", result )

	result = calculator( x , y, substraction )
	fmt.Println("Result : ", result )	

	result = calculator( x , y, multiplication )
	fmt.Println("Result : ", result )	
}

//_______________________________________________

func playWithClosureCaptures() { // Enclosing Context
	var result int 
	start := 0

	incrementBy07 := func() int { // Enclosed Context
		// Enclosed Context Captures The Enclosing Context
		// 		Hence start Variable Is Accessible Inside Closure
		start = start + 7
		return start
	}

	incrementBy10 := func() int { // Enclosed Context
		// Enclosed Context Captures The Enclosing Context
		// 		Hence start Variable Is Accessible Inside Closure
		start = start + 10
		return start
	}

	result = incrementBy07()
	fmt.Println("Increment By 07 Result :", result )

	result = incrementBy07()
	fmt.Println("Increment By 07 Result :", result )

	result = incrementBy07()
	fmt.Println("Increment By 07 Result :", result )

	result = incrementBy10()
	fmt.Println("Increment By 10 Result :", result )

	result = incrementBy10()
	fmt.Println("Increment By 10 Result :", result )

	result = incrementBy07()
	fmt.Println("Increment By 07 Result :", result )
}


//_______________________________________________
//_______________________________________________
//_______________________________________________

func main() {
	fmt.Println("\n\nFunction : playWithFunctionsAndClosures")
	playWithFunctionsAndClosures()

	fmt.Println("\n\nFunction : playWithClosureCaptures")
	playWithClosureCaptures()

	// fmt.Println("\n\nFunction : ")
	// fmt.Println("\n\nFunction : ")
	// fmt.Println("\n\nFunction : ")
	// fmt.Println("\n\nFunction : ")
	// fmt.Println("\n\nFunction : ")
	// fmt.Println("\n\nFunction : ")
}


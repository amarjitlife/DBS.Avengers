
package main

import (
	"fmt"
	"image/color"
	"math/cmplx"
	"strings"
	"bytes"
	"strconv"
	"math/big"
)

// In Go Data Types

// int, bool, string, float32, float64
// complex64, complex128

	// 	Zero For bool Type Is false
	//	Zero For int Type Is 0
	//	Zero For float32 And float64 Type Is 0.0
	//	Zero For string Type Is ""
	//	Zero For comlex64 And complex128 Type Is 0 + 0i


// WHAT IS DATA TYPE???

// 		What Type Of Operation You Can Perform?
//		Set Of Values

/*

Numeric types
An integer, floating-point, or complex type represents the set of integer, floating-point, or complex values, respectively. They are collectively called numeric types. The predeclared architecture-independent numeric types are:

uint8       the set of all unsigned  8-bit integers (0 to 255)
uint16      the set of all unsigned 16-bit integers (0 to 65535)
uint32      the set of all unsigned 32-bit integers (0 to 4294967295)
uint64      the set of all unsigned 64-bit integers (0 to 18446744073709551615)

int8        the set of all signed  8-bit integers (-128 to 127)
int16       the set of all signed 16-bit integers (-32768 to 32767)
int32       the set of all signed 32-bit integers (-2147483648 to 2147483647)
int64       the set of all signed 64-bit integers (-9223372036854775808 to 9223372036854775807)

float32     the set of all IEEE-754 32-bit floating-point numbers
float64     the set of all IEEE-754 64-bit floating-point numbers

complex64   the set of all complex numbers with float32 real and imaginary parts
complex128  the set of all complex numbers with float64 real and imaginary parts

byte        alias for uint8
rune        alias for int32
The value of an n-bit integer is n bits wide and represented using two's complement arithmetic.

There is also a set of predeclared integer types with implementation-specific sizes:

uint     either 32 or 64 bits
int      same size as uint
uintptr  an unsigned integer large enough to store the uninterpreted bits of a pointer value

To avoid portability issues all numeric types are defined types and thus distinct except byte, which is an alias for uint8, and rune, which is an alias for int32. E

xplicit conversions are required when different numeric types are mixed in an expression or assignment. For instance, int32 and int are not the same type even though they may have the same size on a particular architecture.

*/


//_______________________________________________

func playWithComplexTypes() {
	var x complex128 = complex(1, 2) // 1 + 2i
	var y complex128 = complex(3, 4) // 3 + 4i

	fmt.Println( x )
	fmt.Println( y )
	fmt.Println( x + y )
	fmt.Println( x - y )
	fmt.Println( x * y )
	fmt.Println( real( x ) )
	fmt.Println( imag( x ) )

	xx := 1 + 2i
	yy := 3 + 4i

	fmt.Println( xx )
	fmt.Println( yy)
	fmt.Println( xx + yy )
	fmt.Println( xx - yy )
	fmt.Println( xx * yy )
	fmt.Println( real( yy ) )
	fmt.Println( imag( yy ) )

	var aa complex64 = complex( 10, 20 )
	var bb complex64 = complex( 10, 20 )

	fmt.Println( aa )
	fmt.Println( bb)
	fmt.Println( aa + bb )
}

//_______________________________________________

func basename( s string ) string {
	for i := len(s) - 1 ; i >= 0 ; i-- {
		if s[i] == '/' {
			s = s[ i + 1 :  ]
			break
		}
	}

	for i := len(s) - 1 ; i >= 0 ; i-- {
		if s[i] == '.' {
			s = s[  : i ]
			break
		}
	}
	return s 
}

func basenameAgain( s string ) string {
	slash := strings.LastIndex( s, "/")
	s = s[ slash + 1 : ]

	if dot := strings.LastIndex( s, "." ) ; dot >= 0 {
		s = s[ : dot ]
	}
	return s
}

func playWithBaseName() {
	fmt.Println( basename("/media/WorkArea/Trainings/DBSTech/Progress"))
	fmt.Println( basename( "/media/WorkArea/Trainings/DBSTech/Progress/GoIntroduction.go" ))

	fmt.Println( basenameAgain("/media/WorkArea/Trainings/DBSTech/Progress"))
	fmt.Println( basenameAgain( "/media/WorkArea/Trainings/DBSTech/Progress/GoIntroduction.go" ))
}


//_______________________________________________

func acos( z complex128 ) color.Color {
	v := cmplx.Acos( z )
	blue 	:= uint8( real( v ) * 128 ) + 127
	red 	:= uint8( imag( v ) * 128 ) + 127

	return color.YCbCr{ 192, blue, red }
}

func sqrt( z complex128 ) color.Color {
	v := cmplx.Sqrt( z )
	blue := uint8( real( v ) * 128 ) + 127
	red := uint8( imag( v ) * 128 ) + 127

	return color.YCbCr{ 128 , blue, red }
}

//_______________________________________________

// In C Language 
// 		There Is No String Type In C
//		String Value Denonted By ""
//		String Is Sequence Of Characters Stored In char Type Array
//		In C Characters Follows ASCII Coding
//		String Values Ends With '\0' i.e. ASCII NUL Value

// In Go Language
//		A string Is An Immtuable Sequence Of Bytes
//		Strings May Contain Arbirary Data, Including Bytes With Value 0
//		But Generally Contains Human Readable Text

//		Text Strings Are Interpreted As UTF-8 Encoded Sequences Of 
//		Unicode Points ( Runes )
//		i.e. It Stores Unicode Characters

// 		Internal Structure Of string Type In Go Lanaguage

//		type _string struct {
//				elements *byte 
//				len 	  int
//	    }			

// String types
	// A string type represents the set of string values. A string value is a (possibly empty) sequence of bytes. 

	//	The number of bytes is called the length of the string and is never negative. Strings are immutable: once created, it is impossible to change the contents of a string. The predeclared string type is string; 

	// The length of a string s can be discovered using the built-in function len. The length is a compile-time constant if the string is a constant. 

	// A string's bytes can be accessed by integer indices 0 through len(s)-1. It is illegal to take the address of such an element; if s[i] is the i'th byte of a string, &s[i] is invalid.

func playWithStringType() {
	s := "Hello World!"

	fmt.Println( s )
	fmt.Println( "Length Of String : ", len( s ))

	s1 := "Hello World!\uD55C"
	fmt.Println( s1 )
	fmt.Println( "Length Of String : ", len( s1 ))

	s2 := "Hello World!\u1112\u1161\u11AB"
	fmt.Println( s2 )
	fmt.Println( "Length Of String : ", len( s2 ))
	fmt.Println( "\u1112" )
	fmt.Println( "\u1161" )
	fmt.Println( "\u11AB" )

// 	"Voulez-vous un café?" using LATIN SMALL LETTER E WITH ACUTE
	eAcuteQuestion := "Voulez-vous un caf\u00E9"
	combinedEAcuteQuestion := "Voulez-vous un caf\u0065\u0301"
	combinedEAcuteQuestion2 := "Voulez-vous un cafe\u0301"
	
	fmt.Println( eAcuteQuestion )
	fmt.Println( "Length Of String : ", len( eAcuteQuestion ))

	fmt.Println( combinedEAcuteQuestion )
	fmt.Println( "Length Of String : ", len( combinedEAcuteQuestion ))

	fmt.Println( combinedEAcuteQuestion2 )
	fmt.Println( "Length Of String : ", len( combinedEAcuteQuestion2 ))

	// Voulez-vous un café
	// Length Of String :  20
	// Voulez-vous un café
	// Length Of String :  21
	// Voulez-vous un café
	// Length Of String :  21

	// fmt.Println( "\u1F600" )
	// fmt.Println( "\u1F603" )
	// fmt.Println( "\u1F604" )

	someString := "✓ Hello, 世界"
    fmt.Println( someString )
	fmt.Println( "Length Of String : ", len( someString ))

    someString = "\u2713 Hello, 世界"
    fmt.Println( someString )
	fmt.Println( "Length Of String : ", len( someString ))

	someString = "日本語"
	fmt.Println( someString )
	fmt.Println( "Length Of String : ", len( someString ))

    Hello世界 := "Identifier In Chinese"
    fmt.Println( Hello世界 )
    fmt.Println( len( Hello世界 ) )

    fmt.Println( "\u0930" )
    fmt.Println( "\u093B" )
    fmt.Println( "\u092E" )

	रम := "Rum"
    fmt.Println( रम )

	fmt.Println( s[0], s[7] )
	fmt.Println( s[ 0 : 5 ] )
	fmt.Println( s[ : 5 ] )
	fmt.Println( s[ 7 :  ] )
	fmt.Println( s[  :  ] )

	fmt.Println( "Goodbye "+ s[ 5 :  ] )

	ss := "Left Foot"
	tt := ss

	fmt.Println( tt )
	ss = ss + ", and Right Foot"
	fmt.Println ( ss )
	fmt.Println( tt )
}

// Function : playWithStringType
// Hello World!
// Length Of String :  12
// Hello World! 한
// Length Of String :  16
// Hello World! 한
// Length Of String :  22

//_______________________________________________

func playWithStringsFunctions() {
    fmt.Println("Contains:  ", strings.Contains("test", "es"))
    fmt.Println("Count:     ", strings.Count("test", "t"))
    fmt.Println("HasPrefix: ", strings.HasPrefix("test", "te"))
    fmt.Println("HasSuffix: ", strings.HasSuffix("test", "st"))
    fmt.Println("Index:     ", strings.Index("test", "e"))
    fmt.Println("Join:      ", strings.Join([]string{"a", "b"}, "-"))
    fmt.Println("Repeat:    ", strings.Repeat("a", 5))
    fmt.Println("Replace:   ", strings.Replace("foo", "o", "0", -1))
    fmt.Println("Replace:   ", strings.Replace("foo", "o", "0", 1))
    fmt.Println("Split:     ", strings.Split("a-b-c-d-e", "-"))
    fmt.Println("ToLower:   ", strings.ToLower("TEST"))
    fmt.Println("ToUpper:   ", strings.ToUpper("test"))
}

//_______________________________________________

func playWithStringIteration() {
	someString := "✓ Hello, 世界"
    fmt.Println( someString )
	fmt.Println( "Length Of String : ", len( someString ))

	for position, value := range someString {
		fmt.Printf("\nAt Position = %d Unicode Point = %U", position, value)
	}

	fmt.Println("\n")
    someString = "\u2713 Hello, 世界"
    fmt.Println( someString )
	fmt.Println( "Length Of String : ", len( someString ))

	for position, value := range someString {
		fmt.Printf("\nAt Position = %d Unicode Point = %U", position, value)
	}

	fmt.Println("\n")
	someString = "日本語"
    fmt.Println( someString )
	fmt.Println( "Length Of String : ", len( someString ))	

	for position, value := range someString {
		fmt.Printf("\nAt Position = %d Unicode Point = %U", position, value)
	}
}

//_______________________________________________

// Copyright 2009 The Go Authors. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

// Package math provides basic constants and mathematical functions.
//
// This package does not guarantee bit-identical results across architectures.

// Mathematical constants.
const (
	E   = 2.71828182845904523536028747135266249775724709369995957496696763 // https://oeis.org/A001113
	Pi  = 3.14159265358979323846264338327950288419716939937510582097494459 // https://oeis.org/A000796
	Phi = 1.61803398874989484820458683436563811772030917980576286213544862 // https://oeis.org/A001622

	Sqrt2   = 1.41421356237309504880168872420969807856967187537694807317667974 // https://oeis.org/A002193
	SqrtE   = 1.64872127070012814684865078781416357165377610071014801157507931 // https://oeis.org/A019774
	SqrtPi  = 1.77245385090551602729816748334114518279754945612238712821380779 // https://oeis.org/A002161
	SqrtPhi = 1.27201964951406896425242246173749149171560804184009624861664038 // https://oeis.org/A139339

	Ln2    = 0.693147180559945309417232121458176568075500134360255254120680009 // https://oeis.org/A002162
	Log2E  = 1 / Ln2
	Ln10   = 2.30258509299404568401799145468436420760110148862877297603332790 // https://oeis.org/A002392
	Log10E = 1 / Ln10
)

// Floating-point limit values.
// Max is the largest finite value representable by the type.
// SmallestNonzero is the smallest positive, non-zero value representable by the type.
const (
	MaxFloat32             = 0x1p127 * (1 + (1 - 0x1p-23)) // 3.40282346638528859811704183484516925440e+38
	SmallestNonzeroFloat32 = 0x1p-126 * 0x1p-23            // 1.401298464324817070923729583289916131280e-45

	MaxFloat64             = 0x1p1023 * (1 + (1 - 0x1p-52)) // 1.79769313486231570814527423731704356798070e+308
	SmallestNonzeroFloat64 = 0x1p-1022 * 0x1p-52            // 4.9406564584124654417656879286822137236505980e-324
)

// Integer limit values.
const (
	intSize = 32 << (^uint(0) >> 63) // 32 or 64

	MaxInt    = 1<<(intSize-1) - 1
	MinInt    = -1 << (intSize - 1)
	MaxInt8   = 1<<7 - 1
	MinInt8   = -1 << 7
	MaxInt16  = 1<<15 - 1
	MinInt16  = -1 << 15
	MaxInt32  = 1<<31 - 1
	MinInt32  = -1 << 31
	MaxInt64  = 1<<63 - 1
	MinInt64  = -1 << 63
	MaxUint   = 1<<intSize - 1
	MaxUint8  = 1<<8 - 1
	MaxUint16 = 1<<16 - 1
	MaxUint32 = 1<<32 - 1
	MaxUint64 = 1<<64 - 1
)

//_______________________________________________

func playWithTypeCasting() {
	var x int8 	= 20
	var y int16 = 100

	// Compilation Error:
	// invalid operation: x + y (mismatched types int8 and int16)
	// z := x + y 

	// Explicitly Convert Types
	z := x + int8( y )
	fmt.Println( z )

	var xx int8 	= 20
	var yy int16 	= 2000

	// Explicitly Convert Types
	// Created Mess
	zz1 := xx + int8( yy )
	fmt.Println( zz1 )


	var withdraw int16 	= 2000	
	// Account Balance
	var account uint32 	= 2000

	// Explicitly Convert Types
	// Created Mess

	account = account - uint32( withdraw )
	fmt.Println( account )

	withdraw = 100
	account = account - uint32( withdraw )
	fmt.Println( account )
}

//_______________________________________________


func playWithFloatingPoints() {	
	// float64 Is Default
	var x = 9.888888888888888888888888888000000777
	var y = 8.11111111111111111000000111

	fmt.Println( x )
	fmt.Println( y )

// Function : playWithFloatingPoints
// 9.8888 8888 8888 89
// 8.11111111111111

	var xx float32 = 9.888888888888888888888888888000000777
	var yy float32 = 8.11111111111111111000000111

	fmt.Println( xx )
	fmt.Println( yy )
}

//_______________________________________________

func intsToString( values []int ) string {
	var buffer bytes.Buffer

	buffer.WriteByte( '[' )
	for index, value := range values {
		fmt.Printf("\n At Index : %d Value : %v", index, value)

		if index > 0 {
			buffer.WriteString( "," )
		}
		fmt.Fprintf( &buffer, "%d", value )
	}
	buffer.WriteByte( ']' )

	return buffer.String()
}

func playWithIntToString() {
	fmt.Println( "\n String : ", intsToString( []int { 10, 20, 30, }))
	fmt.Println( "\n String : ", intsToString( []int { 10, 20, 30, 40, 50, 60, 70, 800}))
	fmt.Println( "\n String : ", intsToString( []int { 1000, 2000, 3000, 4000, 9990, 909090, 989898, 7777}))
}

//_______________________________________________

func playWithStringUnicode() {
	const something = `⌘`

	fmt.Printf("Plain String: ")
	fmt.Printf("%s", something)
	fmt.Println()

	fmt.Printf("Plain String: ")
	fmt.Printf("%q", something)
	fmt.Println()

	fmt.Printf("\nHex Bytes: ")
	for i := 0 ; i < len( something ) ; i++ {
		fmt.Printf( " %x ", something[i] )
	}

	fmt.Println("\n")
	someString := "✓ Hello, 世界"
    fmt.Println( someString )
	fmt.Println( "Length Of String : ", len( someString ))

	for position, value := range someString {
		fmt.Printf("\nAt Position = %d Unicode Point = %U", position, value)
	}

	fmt.Printf("\nHex Bytes: ")
	for i := 0 ; i < len( someString ) ; i++ {
		fmt.Printf( " %x ", someString[i] )
	}

	fmt.Println("\n")
	someString = "日本語"
    fmt.Println( someString )
	fmt.Println( "Length Of String : ", len( someString ))	

	for position, value := range someString {
		fmt.Printf("\nAt Position = %d Unicode Point = %U", position, value)
	}

	fmt.Printf("\nHex Bytes: ")
	for i := 0 ; i < len( someString ) ; i++ {
		fmt.Printf( " %x ", someString[i] )
	}
}

// https://codebunk.com/b/5741100496800/
// https://codebunk.com/b/5741100496800/
// https://codebunk.com/b/5741100496800/

//_______________________________________________

func concatinatingStrings() {
	var ss = "Left Foot"
	var tt = ss
	ss = ss + "and Right Foot"
	ss = ss + "Ding Dong" + "Ting Tong" + "Zing Zong"

	fmt.Println( ss )
	fmt.Println( tt )

	// This Is Not Efficient Because Create Intermediate string Objects
	//		For Every + Operation
}

func joinStrings( stringValues ...string ) string {
	// strings.Builder Gives Mutable string
	var stringBuilder strings.Builder

	for _, stringValue := range stringValues {
		stringBuilder.WriteString( stringValue )
	}
	
	// Getting Immutable string Object From strings.Builder
	return stringBuilder.String()
}
// func (b *Builder) Write(p []byte) (int, error)
// func (b *Builder) WriteByte(c byte) error
// func (b *Builder) WriteRune(r rune) (int, error)
// func (b *Builder) WriteString(s string) (int, error)

func playWithJoinStrings() {

	var resultString = joinStrings( "Ding", "Dong" )
	for position, value := range resultString {
		fmt.Printf("\nAt Position = %d Unicode Point = %U", position,	 value)
	}

	fmt.Println()
	fmt.Println( resultString )
	fmt.Println( joinStrings( "Ding", "Dong", "Ting", "Tong" ) )
	fmt.Println( joinStrings( "Ding", "Dong", "0000", "1111", "Ting", "Tong" ) )
}


//_______________________________________________

func playWithStringConversion() {
	x := 123
	y := fmt.Sprintf( "%d", x)
	fmt.Println( y )

	fmt.Println( strconv.Itoa( x ) )

	value, err := strconv.Atoi( "9090909" )
	if err == nil {
		fmt.Println( value )
	} else {
		fmt.Println("Conversion Failed..." )
	}
	
	value, err = strconv.Atoi( "9090XYZ" )
	if err == nil {
		fmt.Println( value )
	} else {
		fmt.Println("Conversion Failed..." )
	}
}

//_______________________________________________

const (
	a = 1
	b 
	c 
	d 
)

const (
	aa = 1
	bb
	cc = 2 
	dd 
)

const (
	a1 = 1
	b1 = 2
	c1 = 3 
	d1 = 4
)

// const (
// 	a2
// 	b2
// 	c2 = 2 
// 	d2 
// )

// Following Both const Declaractions Are Equivalent
const (
	a2 = iota
	b2 = iota
	c2 = iota 
	d2 = iota
)

const (
	a3 = iota
	b3 
	c3 
	d3 
)

func playWithConstant() {
	fmt.Println("a  b  c  d")
	fmt.Println(a, b, c, d)

	fmt.Println("aa  bb  cc  dd")
	fmt.Println(aa, bb, cc, dd)

	fmt.Println("a1  b1  c1  d1")
	fmt.Println(a1, b1, c1, d1)

	fmt.Println("a2  b2  c2  d2")
	fmt.Println(a2, b2, c2, d2)

	fmt.Println("a3  b3  c3  d3")
	fmt.Println(a3, b3, c3, d3)
}


//_______________________________________________

const (
	aaa = 1 << iota // iota = 0  1 << 0 = 2^0
  	bbb = 1 << iota // iota = 1  1 << 1 = 2^1
	ccc = 1 << iota // iota = 2  1 << 2 = 2^2
	xxx = 1 << iota // iota = 3  1 << 3 = 2^3
	ddd = 1 << iota // itoa = 4  1 << 4 = 2^4
)

const (
	aa1 = 1 << iota // iota = 0  1 << 0 = 2^0
  	bb1 = 1 << iota // iota = 1  1 << 1 = 2^1
	cc1 = 1 << iota // iota = 2  1 << 2 = 2^2
	xx1 = 3 		// iota = 3  iota Is Not Used...
	dd1 = 1 << iota // itoa = 4  1 << 4 = 2^4
)

const (
	u 			= iota * 42
	v float64 	= iota * 42
	w 			= iota * 42
)

const x = iota
const y = iota 

type Weekday int

// Type Safe Expression
const (
	Sunday Weekday = iota
	Monday
	Tuesday
	Wednesday
	Thursday
	Friday
	Saturday
)

const (
	_ 	= 1 << ( 10 * iota ) // 2 Raised To Power 0
	KiB // 1 << 10 * 1 = 2^10 
	MiB // 1 << 10 * 2 = 2^20
	GiB // 1 << 10 * 3 = 2^30
	TiB // 1 << 10 * 4 = 2^40
	PiB // and so on...
	EiB
	ZiB
	YiB
)

func playWithConstantAgain() {
	fmt.Println("aaa  bbb  ccc xxx ddd")
	fmt.Println(aaa, bbb, ccc, xxx, ddd)

	fmt.Println("aa1  bb1  cc1 xx1 dd1")
	fmt.Println(aa1, bb1, cc1, xx1, dd1)

	fmt.Println("u 	 v    w")
	fmt.Println(u, v, w)

	fmt.Println("x   y")
	fmt.Println(x , y)

	fmt.Println( "Sunday, Monday, Tuesday, Wednesday, Thursday, Friday, Saturday" )
	fmt.Println( Sunday, Monday, Tuesday, Wednesday, Thursday, Friday, Saturday )

	var someDay Weekday = Sunday
	fmt.Println( someDay )
	someDay = Monday
	fmt.Println( someDay )

	// Comilation Error:
	// cannot use Saturday (constant 6 of type Weekday) as type int 
	//		in variable declaration
	// var someAnotherDay int = Saturday
	// fmt.Println( someAnotherDay )

	bigNum := "1267650600228229401496703205376"
	b, ok := big.NewInt(0).SetString(bigNum, 10)
	fmt.Println(ok, b)
	// true 1267650600228229401496703205376

	b, ok = big.NewInt(0).SetString(ZiB, 10)
	fmt.Println(ok, b)
}

// https://codebunk.com/b/5741100496800/
// https://codebunk.com/b/5741100496800/
// https://codebunk.com/b/5741100496800/

//_______________________________________________
//_______________________________________________
//_______________________________________________
//_______________________________________________
//_______________________________________________
//_______________________________________________
//_______________________________________________


func main() {
	fmt.Println("\n\nFunction : playWithComplexTypes")
	playWithComplexTypes()

	fmt.Println("\n\nFunction : playWithBaseName")
	playWithBaseName()

	fmt.Println("\n\nFunction : playWithStringType")
	playWithStringType()

	fmt.Println("\n\nFunction : playWithStringsFunctions")
	playWithStringsFunctions()

	fmt.Println("\n\nFunction : playWithStringIteration")
	playWithStringIteration()

	fmt.Println("\n\nFunction : playWithTypeCasting")
	playWithTypeCasting()

	fmt.Println("\n\nFunction : playWithFloatingPoints")
	playWithFloatingPoints()

	fmt.Println("\n\nFunction : playWithIntToString")
	playWithIntToString()

	fmt.Println("\n\nFunction : playWithStringUnicode")
	playWithStringUnicode()

	fmt.Println("\n\nFunction : concatinatingStrings")
	concatinatingStrings()

	fmt.Println("\n\nFunction : playWithJoinStrings")
	playWithJoinStrings()

	fmt.Println("\n\nFunction : playWithStringConversion")
	playWithStringConversion()

	fmt.Println("\n\nFunction : playWithConstant")
	playWithConstant()

	fmt.Println("\n\nFunction : playWithConstantAgain")
	playWithConstantAgain()

	// fmt.Println("\n\nFunction : ")
	// fmt.Println("\n\nFunction : ")
	// fmt.Println("\n\nFunction : ")
	// fmt.Println("\n\nFunction : ")
	// fmt.Println("\n\nFunction : ")
	// fmt.Println("\n\nFunction : ")
	// fmt.Println("\n\nFunction : ")
}


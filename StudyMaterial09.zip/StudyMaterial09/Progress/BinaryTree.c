
#include <stdio.h>
#include <stdlib.h>

typedef struct item_type {
	int data;
} Item;

typedef struct node_type {
	Item item;
	struct node_type * left;
	struct node_type * right;
} Node;


Node * createNode( Item item ) {
	Node * node = ( Node * ) malloc( sizeof( Node ) ) ;
	// Initialise Node
	node -> item 	= item; 
	node -> left 	= NULL;
	node -> right 	= NULL;

	return node;
}

void addNode( Node *head, Node *node ) {
	if ( head == NULL ) {
		printf("\n Create Empty List First with Head Node...");
		return;
	}

	Node *move = head;
	// Traverse Till End
	for ( 		; move -> next != NULL ; move = move -> next ) ;

	move -> next = node;
}

Node * createList() {
	Item item;
	Node *node;

	item.data = 0;
	Node * head = createNode( item );
	
	item.data = 1;
	node = createNode( item );
	addNode( head, node );

	item.data = 2;
	node = createNode( item );
	addNode( head, node );

	item.data = 3;
	node = createNode( item );
	addNode( head, node );

	// printf("\n %d ", head -> item.data );
	return head;
}

void traverseList( Node * head ) {
	for ( Node *move = head ; move != NULL ; move = move -> next ) {
		printf("\n Data Item : %d", move -> item.data )  ;
	}
}

int main() {
	Node * list = createList();
	traverseList( list );
}


package learnKotlin

interface Superpower {
	fun fly()
	fun saveWorld()
}

class Spiderman : Superpower {
	override fun fly() 		{ println("Fly Like Spiderman!") }
	override fun saveWorld() { println("SaveWorld Like Spiderman!") }
}

class Superman : Superpower {
	override fun fly() 		 { println("Fly Like Superman!") }
	override fun saveWorld() { println("SaveWorld Like Superman!") }
}

class Wonderwoman : Superpower {
	override fun fly() 		 { println("Fly Like Wonderwoman!") }
	override fun saveWorld() { println("SaveWorld Like Wonderwoman!") }
}

class HumanOld : Heman() {
	// fun fly() 		{ println("Fly Like Human!") }
	// fun saveWorld() { println("SaveWorld Like Human!") }
	override fun fly() 		 { super.fly() 		}
	override fun saveWorld() { super.saveWorld() }
}

// Always Prefer Composition Over Inheritance
// 		Embedding Another Object Inside Class
class Human {
	// var power = Spiderman()
	var power : Superpower? = null
	// fun fly() 		{ println("Fly Like Human!") }
	// fun saveWorld() { println("SaveWorld Like Human!") }
	fun fly() 		 { power?.fly() 	  }
	fun saveWorld()  { power?.saveWorld() }
}

// SOLID DESIGN PRACTICE
// S : Single Responsibility Design
//			Class Should Do One Thing And Very Well!!!
// O : Open-Close Principle Design
//			Design Classes Open For Extension And Close For Modification

fun main() {
	// val human = HumanOld()
	// human.fly()
	// human.saveWorld()

	val human = Human()
	human.power = Spiderman() 	// Configuring Human
	human.fly()
	human.saveWorld()

	human.power = Superman() 	// Configuring Human
	human.fly()
	human.saveWorld()

	human.power = Wonderwoman() // Configuring Human
	human.fly()
	human.saveWorld()

	human.power = Batman() 		// Configuring Human
	human.fly()
	human.saveWorld()

	// val spiderman = Spiderman()
	// spiderman.fly()
	// spiderman.saveWorld()
}

class Batman : Superpower {
	override fun fly() 		 { println("Fly Like Batman!") }
	override fun saveWorld() { println("SaveWorld Like Batman!") }
}

open class Heman {
	open fun fly() 		 { println("Fly Like Heman!") }
	open fun saveWorld() { println("SaveWorld Like Heman!") }
}



package main 

import (
	"fmt"
	"math/rand"
	// "strings"
	// "bufio"
	// "strconv"
	// "os"
	"bytes"
	// "github.com/quchunguang/trygo"
	"encoding/json"
	"log"
)


//_______________________________________________

// Associative Types

type Circle struct {
	X, Y, Radius int 
}

type Wheel struct {
	X, Y, Radius, Spokes int
}

func playWithCircleAndWheel() {
	var c Circle
	c.X = 10
	c.Y = 20
	c.Radius = 50

	fmt.Println("Circle :", c)

	var w Wheel
	w.X = 11
	w.Y = 22
	w.Radius = 55
	w.Spokes = 24

	fmt.Println("Wheel  :", w)
}

//_______________________________________________

// DRY : Don't Repeat Yourself

// https://codebunk.com/b/3741100498789/
// https://codebunk.com/b/3741100498789/
type Point1 struct {
	X int
	Y int
}

type Circle1 struct {
	Center Point1
	Radius int 
}

type Wheel1 struct {
	Circle Circle1
	Spokes int
}

func playWithCircleAndWheel1() {
	var c Circle1
	c.Center.X = 10
	c.Center.Y = 20
	c.Radius = 50

	fmt.Println("Circle 1:", c)

	var w Wheel1
	w.Circle.Center.X = 11
	w.Circle.Center.Y = 22
	w.Circle.Radius = 55
	w.Spokes = 24

	fmt.Println("Wheel 1 :", w)
}

//_______________________________________________
// MOMENT DONE! RAISE YOUR FLAGS!!!

// https://codebunk.com/b/5771100498802/
// https://codebunk.com/b/5771100498802/

type Point struct {
	X int
	Y int
}

func ScalePoint( point Point, factor int ) Point {
	return Point{ point.X * factor, point.Y * factor }
}

func AddPoints( point1 Point, point2 Point ) Point {
	return Point{ point1.X * point2.X, point1.Y + point2.Y }
}

func playWithPointType() {
	point1 := Point{ 10 , 20  }
	point2 := Point{ 100, 200 }
	point3 := Point{ 10 , 20  }

	fmt.Println("point1 :", point1 )
	fmt.Println("point2 :", point2 )
	fmt.Println("point3 :", point3 )

	fmt.Println("point1 == point2 :", point1.X == point2.X && point1.Y == point2.Y )
	fmt.Println("point1 == point2 :", point1.X == point3.X && point1.Y == point3.Y )

	fmt.Println("point1 == point2 :", point1 == point2 )
	fmt.Println("point1 == point3 :", point1 == point3 )

	fmt.Println("point1 * 10 :", ScalePoint( point1, 10 ) )
	fmt.Println("point2 * 5 :", ScalePoint( point2, 5 ) )
	fmt.Println("point3 * 7 :", ScalePoint( point3, 7 ) )

	point4 := AddPoints( point1, point2 )
	fmt.Println("point4 :", point4 )

	point5 := AddPoints( point1, point3 )
	fmt.Println("point5 :", point5 )
}


//_______________________________________________

type Point2 struct {
	X int
	Y int
}

type Circle2 struct {
	// Center Point2
	Point2      	// Type/Structure Embedding
	Radius int
}

type Wheel2 struct {
	// Circle Circle2
	Circle2        	// Type/Structure Embedding
	Spokes int
}

func playWithCircleAndWheel2(){
	var w Wheel2

	w.Circle2.Point2.X = 11
	w.Circle2.Point2.Y = 22
	w.Circle2.Radius   = 55
	w.Spokes = 24

	fmt.Println("Wheel 2 : ", w)

	// Can Access Directly Members Of The Embedded Type/Structure
	w.X = 110
	w.Y = 220
	w.Radius = 550
	w.Spokes = 240

	fmt.Println("Wheel 2 : ", w)

	var ww Wheel2
				// Circle2                         Spokes
				//					X   Y    Radius							
	ww = Wheel2{ Circle2 { Point2{ 80, 90 }, 100 }, 244 }
	fmt.Println("Wheel 2 : ", ww)

	ww = Wheel2 {
		// Can Use Labels i.e. Circle2 Is Used As Label
		Circle2 : Circle2 {
			Point2 : Point2 { 888, 999 },
			Radius : 777 },
		Spokes : 99,
	}
	
	fmt.Println("Wheel 2 : ", ww)
}

//_______________________________________________


type tree struct {
	value int
	left, right *tree
}

func add( t * tree, value int ) *tree {
	if t == nil {
		t = new( tree )
		t.value = value
		return t
	}

	if value < t.value {
		t.left = add( t.left, value )
	} else {
		t.right = add( t.right, value )
	}

	return t
}

func appendValues( values[]int, t *tree ) []int {
	if t != nil {
		values = appendValues( values, t.left )
		values = append( values, t.value )
		values = appendValues( values, t.right )
	}
	return values
}

func Sort( values[]int ) {
	var root *tree

	for _, v := range values {
		root = add( root, v )
	}
	appendValues( values[ : 0 ], root )
}

func playWithTreeSort( ) {
	data := make( []int, 20 )

	for i := range data { data[i] = rand.Int() % 20 }
	Sort( data )

	fmt.Println("Data :", data )
}

// https://codebunk.com/b/9091100499402/
// https://codebunk.com/b/9091100499402/
// https://codebunk.com/b/9091100499402/

//_______________________________________________

// new Is a built-in function that allocates memory, 
// but unlike its namesakes in some other languages 
// it does not initialize the memory, it only zeros it. 
// That is, new(T) allocates zeroed storage for a new item of type T 
// and returns its address, a value of type *T. 
// In Go terminology, it returns a pointer to a newly allocated 
// zero value of type T.

// Since the memory returned by new is zeroed, 
// it's helpful to arrange when designing your data structures 
// that the zero value of each type can be used without 
// further initialization. This means a user of the data structure 
// can create one with new and get right to work

// Back to allocation. The built-in function make(T, args) serves 
// a purpose different from new(T). It creates slices, maps, and 
// channels only, and it returns an initialized (not zeroed) value 
// of type T (not *T). The reason for the distinction is that these 
// three types represent, under the covers, references to data structures 
// that must be initialized before use. A slice, for example, is a 
// three-item descriptor containing a pointer to the data 
// (inside an array), the length, and the capacity, and until 
// those items are initialized, the slice is nil. For slices, maps, 
// and channels, make initializes the internal data structure and 
// prepares the value for use. For instance,

// 		make([]int, 10, 100)

// allocates an array of 100 ints and then creates a slice structure 
// with length 10 and a capacity of 100 pointing at the first 10 
// elements of the array. (When making a slice, the capacity can 
// be omitted; see the section on slices for more information.) 

// In contrast, new([]int) returns a pointer to a newly allocated, 
// zeroed slice structure, that is, a pointer to a nil slice value.

type SyncedBuffer struct {
	// contains filtered or unexported fields
}

func playWithNewAndMake() {
	p0 := new( SyncedBuffer )  // type *SyncedBuffer
	var v0 SyncedBuffer      // type  SyncedBuffer

	// Allocate enough memory to store a bytes.Buffer value
	// and return a pointer to the value's address.
	var buf bytes.Buffer
	p1 := &buf

	// Use a composite literal to perform allocation and
	// return a pointer to the value's address.
	p2 := &bytes.Buffer{}

	// Use the new function to perform allocation, which will
	// return a pointer to the value's address.
	p3 := new(bytes.Buffer)

	// Using make() to initialize a map.
	m1 := make(map[string]bool, 0)

	// Using a composite literal to initialize a map.
	m2 := map[string]bool{}

	// allocates slice structure; *p == nil; rarely useful
	var p4 *[]int = new([]int)

	// the slice v now refers to a new array of 100 ints       
	var v1  []int = make([]int, 100) 

	// Unnecessarily complex:
	var p5 *[]int = new([]int)
	*p5 = make([]int, 100, 100)

	// Idiomatic:
	v2 := make([]int, 100)

	fmt.Println( p0, v0, p1, p2, p3, p4, p5, m1, m2, v1, v2 )
}


//_______________________________________________

type Movie struct {
	Title 	string
	Year 	int 		`json:"Released Year"`
	Color 	bool  		`json:"Movie Color"`
	Actors  []string
}

func createMovies() []Movie {
	var movies = []Movie{
		{
			Title	: "Dil Wale Dulhinia Le Jayengain",
			Year 	: 1992,
			Color  	: true,
			Actors  : []string{ "Kajol", "Shahrukh", "AmrishPuri" },
		},

		{
			Title  	: "Sholay",
			Year   	: 1980,
			Color   : true,
			Actors  : []string { "AmitabhBachan", "Dharamender", "GabbarSingh", "Hemamalini"},
		},

		{
			Title 	: "Mughle Azam",
			Year 	: 1960,
			Color 	: false,
			Actors  : []string { "DilipKumar", "Madhubala", "PritviRajKappor"},
		},

		{
			Title 	: "RRR",
			Year 	: 2022,
			Color 	: true,
			Actors  : []string { "NTR", "AliaBhat", "Ramcharan", "AjayDevgan" },
		},
	}

	return movies;
}

func playWithMovies() {
	var movies = createMovies()

	{ 	// Block Scope
		jsonData, err := json.Marshal( movies ) 

		if err != nil {
			log.Fatalf("JSON Marshalling Failed : %s", err )
		}

		fmt.Printf("%s\n", jsonData )
	}

	{
		jsonData, err := json.MarshalIndent( movies, "", "	" ) 
		if err != nil {
			log.Fatalf("JSON Marshalling Failed : %s", err )
		}
		fmt.Printf("%s\n", jsonData )

		var titles []struct { Title string }
		if err := json.Unmarshal( jsonData, &titles  ) ; err != nil {
			log.Fatalf("JSON UnMarshalling Failed : %s", err )
		}

		fmt.Println()		
		fmt.Println( titles )

		var movies []Movie
		if err := json.Unmarshal( jsonData, &movies  ) ; err != nil {
			log.Fatalf("JSON UnMarshalling Failed : %s", err )
		}

		fmt.Println()		
		fmt.Println( movies )
	}
}

// https://codebunk.com/b/9091100499402/
// https://codebunk.com/b/9091100499402/
// https://codebunk.com/b/9091100499402/

//_______________________________________________


//_______________________________________________
//_______________________________________________
//_______________________________________________
//_______________________________________________

func main() {

	fmt.Println("\n\nFunction : playWithCircleAndWheel")
	playWithCircleAndWheel()

	fmt.Println("\n\nFunction : playWithCircleAndWheel1")
	playWithCircleAndWheel1()

	fmt.Println("\n\nFunction : playWithPointType")
	playWithPointType()

	fmt.Println("\n\nFunction : playWithCircleAndWheel2")
	playWithCircleAndWheel2()

	fmt.Println("\n\nFunction : playWithTreeSort")
	playWithTreeSort()

	fmt.Println("\n\nFunction : playWithMovies")
	playWithMovies()

	// fmt.Println("\n\nFunction : ")
	// fmt.Println("\n\nFunction : ")
	// fmt.Println("\n\nFunction : ")
	// fmt.Println("\n\nFunction : ")
	// fmt.Println("\n\nFunction : ")
}


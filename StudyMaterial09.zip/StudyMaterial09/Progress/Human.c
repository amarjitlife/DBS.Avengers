
#include <stdio.h>

typedef struct human_ability {

} HumanAbility;

typedef struct human_type {
	int id;
	char name[20];
	HumanAbility ability;

	void (*dance)();
} Human;

void doBhangra() {
	printf("\nBalleee Ballleeee....");
}

void doKuchipudi() {
	printf("\nEye Moments....");	
}

void playWithHuman() {
				  // Constructor Call	
	Human alice = { 100, "Alice Carol", doKuchipudi };
	printf("\nAlice ID  : %d", alice.id );
	printf("\nAlice Name: %s", alice.name );

	alice.dance();

				  // Constructor Call	 	
	Human singh = { 100, "Santa Singh", doBhangra };
	printf("\nSingh ID  : %d", singh.id );
	printf("\nSingh Name: %s", singh.name );

	singh.dance();
}

int main() {
	playWithHuman();
}


package examples;

class Human {
	public void fly() 		{ System.out.println("Fly Like Human!") ;	    }
	public void saveWorld() { System.out.println("Save World Like Human!"); }
}


class PlayHuman {
	public static void main( String args[] ) {
		Human human = new Human();

	}
}

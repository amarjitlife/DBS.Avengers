
package main 

import (
	"fmt"
	"math/rand"
	"strings"
	"bufio"
	"strconv"
	"os"
)


//_______________________________________________

func playWithBitwiseOperators() {
	var x = 10
	var y = 99
	
	fmt.Printf("\n%b", x)
	fmt.Printf("\n%b", y)

	fmt.Printf("\n%b", x | y )
	fmt.Printf("\n%b", x & y )
	fmt.Printf("\n%b", x ^ y )
}

//_______________________________________________

// Given operands a, b
// AND(a, b) = 1; only if a = b = 1
//                else = 0

func playWithBitwiseAndOperator() {
    var x uint8 = 0xAC    // x = 10101100

	// x = 		1010 1100
	//	   & 	11110000

	fmt.Printf("\n%b", x)
    x &= 0xF0             // x = 10100000
	fmt.Printf("\n%b", x)
}

func playWithBitwiseAndOperatorUseCase() {
    for x := 0; x < 100; x++ {
        num := rand.Int()
        if num & 1 == 1 {
            fmt.Printf("%d is odd\n", num)
        } else {
            fmt.Printf("%d is even\n", num)
        }
    }
}

// Given operands a, b
// OR(a, b) = 1; when a = 1 or b = 1
//               else = 0 

func playWithBitwiseOrOperator() {
    var x uint8 = 10 		// 		00001010
    x |= 196  				// | 	11000100
    fmt.Printf("\n%b", x)   // 		11001110
}

// Given operands a, b
// XOR(a, b) = 1; only if a != b
//      else = 0

func playWithBitwiseXorOperator0() {
    var x uint16 = 0xCEFF	// 	  1100 1110 1111 1111
    x ^= 0xFF00 			// 	^ 1111 1111 0000 0000

    fmt.Printf("\n%b", x)   // 0011 0001 1111 1111
}

func playWithBitwiseXorOperator1() {
    var x byte = 0x0F  			//0000 1111
    fmt.Printf("%08b\n", x) 	//0000 1111	
    fmt.Printf("%08b\n", ^x) 	//1111 0000

    // In Go ^x = 1 ^ x which reverses Bit In x
}

// Given operands a, b
// AND_NOT(a, b) = AND(a, NOT(b))
	
	// AND_NOT(a, 1) = 0; clears a
	// AND_NOT(a, 0) = a; 

func playWithBitwiseAndNotOperator() {
    var x byte = 0xAB         	// 	1010 1011
     
     fmt.Printf("%08b\n", x)    // 		1010 1011
     x &^= 0x0F                 //&^ 	0000 1111   
     fmt.Printf("%08b\n", x)    //		1010 0000
}


//_______________________________________________

type Flags uint

const (
	FlagUp Flags 	= 1 << iota
	FlagBroadcast
	FlagLoopback
	FlagPointToPoint
	FlagMulticast
)

func IsUp(v Flags) bool 	{ return v & FlagUp == FlagUp }
func TurnDown(v *Flags)		{ *v &^= FlagUp } // &^ (AND NOT) This Will Clear Bit
func SetBroadcast(v *Flags) { *v |= FlagBroadcast }
func IsCast(v Flags) bool 	{ return v & (FlagBroadcast | FlagMulticast ) != 0 }

func playWithFlags() {
	var v Flags = FlagMulticast | FlagUp

	fmt.Printf("%b %t\n", v, IsUp( v ) )
	TurnDown( &v )
	fmt.Printf("%b %t\n", v, IsUp( v ) )

	SetBroadcast( &v )
	fmt.Printf("%b %t\n", v, IsUp( v ) )
	fmt.Printf("%b %t\n", v, IsCast( v ) )
}

// Operator precedence
// Unary operators have the highest precedence. 
// As the ++ and -- operators form statements, not expressions, 
// they fall outside the operator hierarchy. 
// As a consequence, statement *p++ is the same as (*p)++.

// There are five precedence levels for binary operators. 
// Multiplication operators bind strongest, 
// followed by addition operators, comparison operators, 
// && (logical AND), and finally || (logical OR):

// Precedence    	Operators
//     5             *  /  %  <<  >>  &  &^
//     4             +  -  |  ^
//     3             ==  !=  <  <=  >  >=
//     2             &&
//     1             ||

// Binary operators of the same precedence associate from 
// left to right. For instance, x / y * z is the same as (x / y) * z.

//NOTE : Precedence Order and Rules Are Not Same In Go and C
// 		https://go.dev/ref/spec#Operators
// 		https://en.cppreference.com/w/c/language/operator_precedence

//_______________________________________________

const (
	UPPER = 1 // upper case
	LOWER = 2 // lower case
	CAP   = 4 // capitalizes
	REV   = 8 // reverses
)

func processString(str string, conf byte) string {
    // reverse string
	rev := func(s string) string {
		runes := []rune(s)
		n := len(runes)
		for i := 0; i < n/2; i++ {
			runes[i], runes[n-1-i] = runes[n-1-i], runes[i]
		}
		return string(runes)
	}
	
	// query configs
	if (conf & UPPER) != 0 {
		str = strings.ToUpper(str)
	}
	if (conf & LOWER) != 0 {
		str = strings.ToLower(str)
	}
	if (conf & CAP) != 0 {
		str = strings.Title(str)
	}
	if (conf & REV) != 0 {
		str = rev(str)
	}
	return str
}

func playWithProcessString() {
	fmt.Println( processString("HELLO PEOPLE!", LOWER|REV|CAP) )
}

//_______________________________________________

func playWithArrays() {
	// Initialised To Zero Of Type int
	var a [3]int

	for index, value := range a {
		fmt.Printf("\nAt Index : %d, Value : %d", index, value)
	}
	fmt.Println( a[0] )
	fmt.Println( a[1] )
	fmt.Println( a[2] )
	// Compilation Error
	// invalid argument: array index 3 out of bounds [0:3]
	// fmt.Println( a[3] )
	fmt.Println( a[ len(a) - 1 ] )
	for _, value := range a {
		fmt.Println( value )
	}

	var q [5]int = [5]int { 10, 20, 30, 40, 50 }
	var r [5]int = [5]int { 10, 20, 30 }

	fmt.Println("\nArray Length: ", len( q ) )
	for index, value := range q {
		fmt.Printf("\nAt Index : %d, Value : %d", index, value)
	}

	fmt.Println("\nArray Length: ", len( r ) )
	for index, value := range r {
		fmt.Printf("\nAt Index : %d, Value : %d", index, value)
	}

	s := [...]int{ 10, 20, 30, 111 }
	fmt.Println("\nArray Length: ", len( s ) )
	for index, value := range s {
		fmt.Printf("\nAt Index : %d, Value : %d", index, value)
	}

	some := [3]int{ 100, 200, 300 }
	fmt.Println("\nArray Length: ", len( some ) )
	fmt.Printf("\nData Type: %T", some )

	someAgain := [...]int{ 99 : -1  }
	fmt.Println("\nArray Length: ", len( someAgain ) )
	fmt.Printf("\nData Type: %T", someAgain )

	fmt.Println()
	for index, value := range someAgain {
		fmt.Printf(" Index : %d, Value : %d ###", index, value)
	}

	fmt.Println()
	fmt.Println( q )
	fmt.Println( r )
	fmt.Println( s )
	fmt.Println( some )
	fmt.Println( someAgain )

	aa := [2]int { 10, 20 }
	bb := [...]int {10, 20 }
	cc := [2]int { 10, 30 }

	fmt.Println( aa == bb, aa == cc, bb == cc )

	// Compilation Error
	// invalid operation: cc == dd (mismatched types [2]int and [3]int)
	// dd := [3]int { 10, 30 }
	// fmt.Println( cc == dd )
}

//_______________________________________________

// In C/C++/Java By Default:
//		Arrays Are Pass By Reference

// In Go By Default:
//		Arrays Are Pass By Value
//		Function Will By Default Creates Local Copy 
// 			Of The The Whole Arrayi.e. All It's Elements

func changeArray( a [5]int ) {
	for i, _ := range a {
		a[ i ] = 777;
	}
	fmt.Println( "Array Inside Function: ", a )
}

func changeArrayAgain( a *[5]int ) {
	for i, _ := range a {
		a[ i ] = 777;
	}
}

func playWithChangeArray() {
	var aa [5]int = [5]int { 10, 20, 30, 40, 50 }

	fmt.Println("Array Elements Before changeArray :", aa )
	changeArray( aa )
	fmt.Println("Array Elements After  changeArray :", aa )

	fmt.Println("Array Elements Before changeArrayAgain :", aa )
	changeArrayAgain( &aa )
	fmt.Println("Array Elements After  changeArrayAgain :", aa )
}

//_______________________________________________

type Currency int

const (
	USD Currency = iota
	EUR
	GBP = 4
	RMB
)

func playWithCorrency() {
	fmt.Println( USD, EUR, GBP, RMB )
}

func zero( ptr * [10]byte ) {
	for i := range ptr {
		ptr[i] = 0
	}
}

func zeroAgain( ptr * [10]byte ) {
	*ptr = [10]byte { }
}

func playWithArraysAgain() {
	q := [...]int { 1, 2, 3 }

	fmt.Printf("\n%T ", q)
	fmt.Println( q )

	qq := [3]int { 1, 2, 3 }
	// cannot use [4]int{…} (value of type [4]int) as type [3]int in assignment
	// qq  = [4]int { 10, 30, 30, 40 }
	fmt.Println( qq )

	p := [...]byte { 1, 1, 2, 3, 4, 8, 7, 9, 8, 9 }
	fmt.Println( p )
	zero( &p )
	fmt.Println( p )

	pp := [...]byte { 1, 1, 2, 3, 4, 8, 7, 9, 8, 9 }
	fmt.Println( pp )
	zeroAgain( &pp )
	fmt.Println( pp )
}

//_______________________________________________

// In C/C++/Java
// 		changeArrayAgain1 Function Takes Argument Array of Int
// int changeArrayAgain1( int a[] ) {

// }

// In Go Lang
// 		changeArrayAgain1 Function Takes Argument Slice Of Int Array

// cannot use cc (variable of type [10]int) as type []int in argument
func changeArrayAgain1( a []int ) {
	for i, _ := range a {
		a[ i ] = 777;
	}
}

func playWithArraysAndSlices() {
	var cc [10]int = [10]int{ 10, 20, 30, 40, 50, 60, 70, 80, 90, 00 }

	var slice = cc[ : 5 ]
	fmt.Println( slice )

	slice = cc[ 4 :  ]
	fmt.Println( slice )

	slice = cc[ 3 : 7 ]
	fmt.Println( slice )

	//invalid argument: array index 12 out of bounds [0:11
	// slice = cc[ 3 : 12 ]
	// fmt.Println( slice )
	slice = cc[ : ]
	fmt.Println( slice )

	fmt.Println( cc ) 
	// Passing Slice To Function
	//		Slices Are Pass By Reference
	changeArrayAgain1( cc[ : 2 ] )
	fmt.Println( cc )	

	fmt.Println( cc ) 
	// Passing Slice To Function
	//		Slices Are Pass By Reference
	changeArrayAgain1( cc[ 7 :  ] )
	fmt.Println( cc )	

	fmt.Println( cc ) 
	// Passing Slice To Function
	//		Slices Are Pass By Reference
	changeArrayAgain1( cc[  :  ] )
	fmt.Println( cc )	
}

//_______________________________________________

func playWithArrayAndSlicesEquality() {
	var a1 [5]int = [...]int{ 10, 20, 30, 40, 50 }
	fmt.Println( a1 )

	var b1 [5]int = [...]int{ 10, 20, 30, 40, 50 }
	fmt.Println( b1 )

	var c1 [5]int = [...]int{ 10, 20, 30, 40, 60 }
	fmt.Println( c1 )

	fmt.Println( a1 == b1, a1 == c1, b1 == c1 )
	// cannot use [...]int{…} (value of type [4]int) as type 
	// [5]int in variable declaration
	// var aa [5]int = [...]int{ 10, 20, 30, 40 }

	var cc [10]int = [10]int{ 10, 20, 30, 40, 50, 60, 70, 80, 90, 00 }
	var slice1 = cc[ : 5 ]
	var slice2 = cc[ : 5 ]

	fmt.Println( slice1 )
	fmt.Println( slice2 )

	// Compilation Error
	// invalid operation: slice1 == slice2 (slice can only be compared to nil)
	// fmt.Println( slice1 == slice2 )
	slice1 = nil
	slice2 = nil

	fmt.Println( slice1, slice2 )
	fmt.Println( slice1 == nil , slice2 == nil  )
}

//_______________________________________________


func playWithMonthsSlices( ) {
	months := [...]string { 0 : "", "Jan", "Feb", "Mar", "Apr", "May", "Jun",
			"Jul", "Aug", "Sep", "Oct", "Nov", "Dec" }

	fmt.Println( "Months: ", months )

	quater1 := months[ 1 : 4 ]
	quater2 := months[ 4 : 7 ]
	summer  := months[ 3 : 8 ]

	fmt.Println("Quater 1 : ", quater1 )	
	fmt.Println("Quater 2 : ", quater2 )	
	fmt.Println("Summer   : ", summer )	

	for _, s := range summer {
		for _, q := range quater2 {
			if s == q {
				fmt.Printf("\n %s  Appears In Both", s )
			}
		}
	}
}



//______________________________________________________________________
// 						
// 						GO SLICES CONCEPTS
//______________________________________________________________________

// Slices represent variable-length sequences whose elements all 
// have the same type. A slice type is written []T, where the 
// elements have type T; 
// 		it looks like an array type without a size.

// A slice is a lightweight data structure that gives access to 
// a subsequence (or perhaps all) of the elements of an array, 
// which is known as the slice’s underlying array. 

// 	A slice has three components: a pointer, a length, and a capacity. 
// 		The pointer points to the first element of the array that 
//			is reachable through the slice, which is not necessarily 
//			the array’s first element. 
// 		The length is the number of slice elements; it can’t 
//			exceed the capacity, which is usually the number of elements between 
// 			the start of the slice and the end of the underlying array. 

// 		The built-in functions len and cap return those values.

// The slice operator s[ i : j ], where 0 ≤ i ≤ j ≤ cap(s), 
// 	Creates a new slice that refers to elements i through 
//  j-1 of the sequence s,  which may be an array variable, 
//  a pointer to an array, or another slice. 
// 	The resulting slice has j-i elements. 
// 	If i is omitted,it’s 0,and if j isomitted, it’s len(s). 

// 	Thus the slice months[1:13] refers to the whole range of 
//  valid months,  as does the slice months[1:]; 
//  the slice months[:] refers to the whole array.


//_______________________________________________

// THINK LIKE C AND CODE LIKE PYTHON

func playWithModifiicationsUsingSlices( ) {
	numbers := [...]int { 10, 20, 30, 40, 50, 60, 70, 80, 90, 11, 22, 33, 44 }

	fmt.Println( "Months: ", numbers )

	numbersQuater1 := numbers[ 1 : 4 ]
	numbersQuater2 := numbers[ 4 : 7 ]
	commonSlice    := numbers[ 3 : 8 ]

	fmt.Println("Quater 1 : ", numbersQuater1 )	
	fmt.Println("Quater 2 : ", numbersQuater2 )	
	fmt.Println("Commmon  : ", commonSlice )	

	for i := range commonSlice {
		commonSlice[ i ] = 0 
	}

	fmt.Println("Quater 1 : ", numbersQuater1 )	
	fmt.Println("Quater 2 : ", numbersQuater2 )	
	fmt.Println("Commmon  : ", commonSlice )	

	numbersAgain := [...]int { 10, 20, 30, 40, 50, 60, 70, 80, 90, 11, 22, 33, 44 }

	numbersAgainQuater1 := numbersAgain[ 1 : 4 ]

	fmt.Println("Numbers Quater1  : ", numbersAgainQuater1 )	
	fmt.Println("Numbers Quater1  : ", numbersAgainQuater1[ : ]  )	

	fmt.Println("Numbers Quater1  : ", numbersAgainQuater1[ : 4 ]  )
	// Numbers Quater1  :  [20 30 40 50]
	// Above Slice Will Pick Elements With Following Logic
	//for ( i = 0, element =  1 + i ; i < 4 ; i++  ) { numbersAgainQuater1[ element ] }
	
	fmt.Println("Numbers Quater1  : ", numbersAgainQuater1[ : 12 ]  )	
	fmt.Println("Numbers Quater1  : ", numbersAgainQuater1[ 4 : 12 ]  )	
	// Numbers Quater1  :  [60 70 80 90 11 22 33 44]
	// Above Slice Will Pick Elements With Following Logic
	//for ( i = 0, element =  4 + i ; i < 12 ; i++  ) { numbersAgainQuater1[ element ] }
	
	numbersOnceMore := numbersAgainQuater1[ 3 : 7 ]
	fmt.Println( numbersOnceMore )
	fmt.Println( numbersOnceMore[ 2 : 4 ] )

	// Runtime Error
	// panic: runtime error: slice bounds out of range [:13] with capacity 12	
	// fmt.Println("Numbers Quater1  : ", numbersAgainQuater1[ : 13 ]  )	
}

//_______________________________________________

func reverse( s []int ) {
	for i, j := 0, len( s ) - 1 ;  i < j  ;  i, j = i + 1, j - 1  {
		s[i], s[j] = s[j], s[i]
	}
}

// Following Both Style Of Functions Arguments Are Equivalent

func playWithReverse() {
	a := [...]int{ 10, 20, 30, 40, 50, 60, 70, 80, 90, 99 }

	fmt.Println( a )
	reverse( a [ : ] )
	fmt.Println( a )

	reverse( a [ : 4 ] )
	fmt.Println( a )

	reverse( a [ 7 :  ] )
	fmt.Println( a )

	// reverse( a )
	// fmt.Println( a )
}

//_______________________________________________

// func equalSlices(x []int, y []int )
func equalSlices( x, y []int ) bool {
	if len( x ) != len( y ) {
		return false
	}

	for i := range x {
		if x[i] != y[i] {
			return false
		}
	}
	return true
}

func playWithEqualSlices() {
	a := [...]int{ 10, 20, 30, 40, 50, 60, 70, 80, 90, 99 }

	slice1 := a[ 2 : 7 ]
	slice2 := a[ 2 : 7 ]
	slice3 := a[ 1 : 7 ]

	fmt.Println("Slices Equal : ", equalSlices( slice1, slice2 ) )
	fmt.Println("Slices Equal : ", equalSlices( slice1, slice3 ) )
	fmt.Println("Slices Equal : ", equalSlices( slice2, slice3 ) )
}

//_______________________________________________

// The built-in function make creates a slice of a specified 
// element type, length, and capacity. The capacity argument 
// may be omitted, in which case the capacity equals the 
// length.
// 		make([]T, len)
// 		make([]T, len, cap) // same as make([]T, cap)[:len]

func playWithArraysAndSlicesFunctions() {
	s := make( []string, 3 )

	fmt.Println("Empty Slice: ", s )
	fmt.Printf("\nEmpty Slice Type: %T", s )
	fmt.Printf("\nLength: %d Capacity: %d", len( s ), cap( s ) )

	s[0] = "Ding"
	s[1] = "Dong"
	s[2] = "Ting"

	fmt.Println("\nSlice: ", s )
	fmt.Printf("\nLength: %d Capacity: %d", len( s ), cap( s ) )

	s = append( s, "Tong" )
	fmt.Println("\nSlice: ", s )
	fmt.Printf("\nLength: %d Capacity: %d", len( s ), cap( s ) )	

	s = append( s, "Ping" )
	s = append( s, "Pong" )
	fmt.Println("\nSlice: ", s )
	fmt.Printf("\nLength: %d Capacity: %d", len( s ), cap( s ) )	

	s = append( s, "Zing" )
	fmt.Println("\nSlice: ", s )
	fmt.Printf("\nLength: %d Capacity: %d", len( s ), cap( s ) )	

	c := make( []string, len( s ) )
	// Shallow Copy
	c = s // Reference Assignment

	fmt.Println("\nSlice s: ", s )
	fmt.Println("Slice c: ", c )

	s[0] = "Hello!"

	fmt.Println("Slice s: ", s )
	fmt.Println("\nSlice c: ", c )

	ss := make( []string, 0 )	
	fmt.Println("\nSlice ss: ", ss )
	fmt.Printf("\nLength: %d Capacity: %d", len( ss ), cap( ss ) )	

	ss = append( ss, "AA", "BB", "CC", "DD", "EE" )
	fmt.Println("\nSlice ss: ", ss )
	fmt.Printf("\nLength: %d Capacity: %d", len( ss ), cap( ss ) )	

	cc := make( []string, len ( ss ) )
	fmt.Println("Slice ss: ", ss )
	fmt.Println("Slice cc: ", cc )

	// Deep Copy : Complete Duplicate Of Obect Created
	copy( cc, ss )
	fmt.Println("\nSlice ss: ", ss )
	fmt.Println("Slice cc: ", cc )

	ss[0] = "Good Afternoon!!!"
	fmt.Println("\nSlice ss: ", ss )
	fmt.Println("Slice cc: ", cc )

	// Creating Slice Using Declarative Syntax
	tt := []string{ "Ding", "Dong", "Ting", "Tong" }
	fmt.Println("\nSlice tt: ", tt )
	fmt.Printf("\nSlice tt Type %T: ", tt )
	fmt.Printf("\nLength: %d Capacity: %d", len( tt ), cap( tt ) )	

	tt = append(tt, "Ping")
	fmt.Printf("\nLength: %d Capacity: %d", len( tt ), cap( tt ) )	
	fmt.Println("\nSlice tt: ", tt )

	// fmt.Println( tt[6] ) 	// tt[ 6 ] Using Indexing Operator
	fmt.Println( tt[ 2 : 7 ] )	// tt[ 2 : 7 ] Is Slicing Operator
}

//_______________________________________________


func playWithReadingUserInputs() {

	input := bufio.NewScanner( os.Stdin )

	outer:
		for input.Scan() {
			var ints []int 

			for _, s := range strings.Fields( input.Text() ) {
				x, err := strconv.ParseInt(s, 10, 64 )

				if err != nil {
					fmt.Fprintln( os.Stderr, err )
					continue outer
				}
				ints = append( ints, int( x ) )
			}

			fmt.Printf("%v\n", ints)
			reverse( ints )
			fmt.Printf("%v\n", ints)
		}
}


//_______________________________________________

func allocate2DArray(rows, columns int ) [][]int {
	array2D := make( [][]int, rows ) 

	for  row := 0 ; row < rows ; row++  {
		array2D[ row ] = make( []int, columns )
		// for column := 0 ; column < innerLen ; column++  {
		// 	twoDimentionalArray[ row ] [ column ] = row + column 
		// }
	}
	return array2D
}

func playWithAllocate2DIntArray() {
	rows := 4
	columns := 3

	var array2D = allocate2DArray( rows, columns )

	fmt.Println("\nAllocated Array Elements...")
	for  row := 0 ; row < rows ; row++  {
		for column := 0 ; column < columns ; column++  {
			fmt.Printf("\nElement At [%d][%d] : %d", row, column, 
				array2D[row][column] )
		}
	}

	for  row := 0 ; row < rows ; row++  {
		for column := 0 ; column < columns ; column++  {
			array2D[row][column] = row + column
		}
	}

	fmt.Println("\nInitialised Array Elements...")
	for  row := 0 ; row < rows ; row++  {
		for column := 0 ; column < columns ; column++  {
			fmt.Printf("\nElement At [%d][%d] : %d", row, column, 
				array2D[row][column] )
		}
	}
}


//_______________________________________________

func appendInt( x []int, y int ) []int {
	var z []int

	zlen := len( x ) + 1
	if zlen <= cap( x ) {
		z = x[ : zlen ]
	} else { // Underlining Array Is Full
		// When Is Full : Allocate New Array
		//		New Array Capacity Is Double Existing Array
		zcap := zlen
		if zcap < 2 * len( x ) {
			zcap = 2 * cap( x )
		}

		z = make ( []int, zlen, zcap )
		copy( z, x )
	}

	z[ len( x ) ] = y
	return z 
}

func playWithAppendInt() {
	var x, y []int
	for i := 0 ; i < 10 ; i++ {
		y = appendInt( x, i )
		fmt.Printf("\n   %d Capacity = %d \t %v", i, cap( y ), y )
		x = y // Note: It's Very Important To Assign To x
	}
}

//_______________________________________________

// Variadiac Arguments
//		Variable Number Of Arguments
//		i.e. Number Of Arguments Can Be 0 To Finite Numbers
func summation( numbers ...int ) int {
	fmt.Printf("Numbers Type: %T numbers: %v", numbers, numbers )
	var total int
	for _, number := range numbers {
		total = total + number
	}
	return total
}

func playWithVaridiacSummationFunction() {
	var result int 

	result = summation()
	fmt.Println("\nSummation :", result)

	result = summation(10, 20, 30, 40)
	fmt.Println("\nSummation :", result)

	result = summation(10, 20, 30, 40, 50, 60, 70, 80, -90)
	fmt.Println("\nSummation :", result)

	result = summation(1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15)
	fmt.Println("\nSummation :", result)

	numbers := []int{ 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 }
	result = summation( numbers... )
	fmt.Println("\nSummation :", result)

	numbersAgain := [...]int{ 1, 2, 3, 4, 5, 6 }
	// result = summation( numbersAgain... )
	result = summation( numbersAgain[ : ]...  )
	fmt.Println("\nSummation :", result)
}

//_______________________________________________
// https://codebunk.com/b/2441100498209/
// https://codebunk.com/b/2441100498209/

func appendInts( x []int, y ...int ) []int {
	var z []int

	zlen := len( x ) + len( y )
	if zlen <= cap( x ) {
		z = x[ : zlen ]
	} else { // Underlining Array Is Full
		// When Is Full : Allocate New Array
		//		New Array Capacity Is Double Existing Array
		zcap := zlen
		if zcap < 2 * len( x ) {
			zcap = 2 * cap( x )
		}

		z = make ( []int, zlen, zcap )
		copy( z, x )
	}

 	copy( z[ len( x ) :  ], y )
	return z 
}

func playWithAppendInts() {
	var x, y []int
	for i := 0 ; i < 10 ; i++ {
		y = appendInts( x, i )
		fmt.Printf("\n   %d Capacity = %d \t %v", i, cap( y ), y )
		x = y // Note: It's Very Important To Assign To x
	}

	fmt.Printf("\n Len = %d Capacity = %d", len(x) , cap(x) )
	fmt.Println( x )

	x = appendInts(x, 100, 200, 300 )
	fmt.Printf("\n Len = %d Capacity = %d", len(x) , cap(x) )
	fmt.Println( x )


	x = appendInts(x, 11, 22, 33, 44, 55, 66, 77 )
	fmt.Printf("\n Len = %d Capacity = %d", len(x) , cap(x) )
	fmt.Println( x )

	numbers := []int{ 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 }
	x = appendInts(x, numbers...)
	fmt.Printf("\n Len = %d Capacity = %d", len(x) , cap(x) )
	fmt.Println( x )

	numbersAgain := [...]int{ 1, 2, 3, 4, 5, 6 }
	x = appendInts(x, numbersAgain[ : ]...)
	fmt.Printf("\n Len = %d Capacity = %d", len(x) , cap(x) )
	fmt.Println( x )
}

//_______________________________________________
// https://codebunk.com/b/2441100498209/
// https://codebunk.com/b/2441100498209/
// https://codebunk.com/b/2441100498209/

func filterEmpty( strings []string ) []string {
	i := 0
	for _, s := range strings {
		if s != "" {
			strings[i] = s
			i++
		}
	}
	return strings[ : i ]
}

func filterEmptyAgain( strings []string ) []string {
	out := strings[ : 0 ] // Zero Length Slice Of Original Slice
	for _, s := range strings {
		if s != "" {
			out = append( out, s )
		}
	}
	return out
}

func playWithFilterEmpty() {
	data := []string{ "One", "Two", "", "Ding", "dong", "", "TING"}
	fmt.Printf("\n %q ", data )
	filteredData := filterEmpty( data )
	fmt.Printf("\n %q ", filteredData )	

	dataAgain := []string{ "One", "Two", "", "Ding", "dong", "", "TING", }
	fmt.Printf("\n %q ", dataAgain )
	filteredDataAgain := filterEmptyAgain( dataAgain )
	fmt.Printf("\n %q ", filteredDataAgain )	

	dataAgain1 := []string{ "One", "Two", "", "Ding", "dong", "", "TING", "", ""}
	fmt.Printf("\n %q ", dataAgain1 )
	filteredDataAgain1 := filterEmptyAgain( dataAgain1 )
	fmt.Printf("\n %q ", filteredDataAgain1 )	
}

//_______________________________________________

func playWithMaps() {
	m := make( map[string]int )

	fmt.Println("Map : ", m)	
	fmt.Println("Map : ", len( m )) 	

	m["Ding"] = 10
	m["Dong"] = 20
	fmt.Println("Map : ", m)	
	m["Ting"] = 100
	m["Tong"] = 200
	fmt.Println("Map : ", m)

	value1 := m["Ding"]
	fmt.Println("Map Key Value : ", "Ding", value1 )
	fmt.Println("Map Length: ", len( m ) )

	m["Ping"] = 222
	fmt.Println("Map : ", m)
	delete(m,"Ting")
	fmt.Println("Map : ", m)

	value2, status := m["Dong"]
	fmt.Println("Map Key Value : ", "Dong", value2, status )
	value2, status = m["Ting"]
	fmt.Println("Map Key Value : ", "Ting", value2, status )

	m["Ping"] = 333
	fmt.Println("Map : ", m)

	// Declarative Syntax To Create Map
	mm := map[string]int { "foo": 0, "bar": 1, "moo": 10, "meion": 99 }
	fmt.Println("Map mm: ", mm)

	mm["bar"] = mm["bar"] + 1
	fmt.Println("Map mm: ", mm)

	mm["bar"] += 1
	fmt.Println("Map mm: ", mm)

	mm["bar"]++
	fmt.Println("Map mm: ", mm)

	drink, ok := mm["bar"]
	if ok {
		fmt.Println("Let's Go... : ", drink)
	}

	// Good Pattern To Write Above Code
	// Idiomatic Style Of Coding
	if drink, ok := mm["bar"] ; ok {
		fmt.Println("Let's Go... : ", drink)
	} 

	// Copiler Error
	// invalid operation: cannot take address of mm["bar"] 
	// (map index expression of type int)
	// address := &mm["bar"]

	var ages map[string]int
	fmt.Printf("\nMap %v Length: %d  Nil: %t", ages, len( ages ), ages == nil )

	// RunTime Error
	// panic: assignment to entry in nil map
	// ages[ "SalmanKhan" ] = 56
	// fmt.Printf("\nMap %v Length: %d  Nil: %t", ages, len( ages ), ages == nil )

	helloJapan := "Hello, 日本語"
	fmt.Println( )
	fmt.Println( helloJapan )

	// CompileTime Error
	// invalid operation: cannot take address of helloJapan[4] 
	// (value of type byte)
	// address := &helloJapan[ 4 ]
	// Because string Type Data Is IMMUTABLE IN GO LANGUAGE

	names := map[string]int{ "Salman" : 56, "Shahrukh" : 60, "Sushmita" : 45 }
	fmt.Println( names )

	namesAgain := map[string]int{ "Salman" : 56, "Shahrukh" : 60, "Sushmita" : 45 }
	fmt.Println( namesAgain )

	// CompileTime Error
	// invalid operation: names == namesAgain (map can only be compared to nil)
	// fmt.Println( names == namesAgain )
}

//_______________________________________________

func equalMaps( x, y map[string]int ) bool {
	if len( x ) != len( y ) {
		return false 
	}
	
	for xk, xv := range x {
		if yv, ok := y[xk] ; !ok || yv != xv {
			return false
		}
	}
	return true
}

func playWithEqualMaps() {
	names := map[string]int{ "Salman" : 56, "Shahrukh" : 60, "Sushmita" : 45 }
	fmt.Println( names )

	names1 := map[string]int{ "Salman" : 56, "Shahrukh" : 60, "Sushmita" : 45, 
	"Alia" : 22 }
	fmt.Println( names1 )

	namesAgain := map[string]int{ "Salman" : 56, "Shahrukh" : 60, "Sushmita" : 45 }
	fmt.Println( namesAgain )

	fmt.Println("Are names And namesAgain Maps Equal? : ", equalMaps(names, namesAgain))
	fmt.Println("Are names And names1 Maps Equal? : ", equalMaps(names, names1))
	fmt.Println("Are names1 And namesAgain Maps Equal? : ", equalMaps(names1, namesAgain))
}


//_______________________________________________


func playWithSlicesDeclarations() {
	// Zero For Slices Is nil 
	// Slices Are By Default Assinged nil Value
	var s0 []int
	
	fmt.Printf("\nSlice %v Length: %d  Nil: %t", s0, len( s0 ), s0 == nil )
	s0 = nil 
	fmt.Printf("\nSlice %v Length: %d  Nil: %t", s0, len( s0 ), s0 == nil )

	// RunTime Error
	// panic: runtime error: index out of range [0] with length 0
	// s0[0] = 9999
	// fmt.Printf("\nSlice %v Length: %d  Nil: %t", s0, len( s0 ), s0 == nil )

	s1 := []int( nil )
	fmt.Printf("\nSlice %v Length: %d  Nil: %t", s1, len( s1 ), s1 == nil )

	s2 := []int{ }
	fmt.Printf("\nSlice %v Length: %d  Nil: %t", s2, len( s2 ), s2 == nil )

	s3 := make( []int, 0 )
	fmt.Printf("\nSlice %v Length: %d  Nil: %t", s3, len( s3 ), s3 == nil )
}

//_______________________________________________

func playWithAppendRunes() {
	var runes []rune
	for _, r := range "Hello, 日本語" {
		runes = append( runes, r )
	}
	fmt.Printf("\n%q", runes)

	runes = []rune( "Hello, 日本語" )
	fmt.Printf("\n%q", runes)
} 
// ['H' 'e' 'l' 'l' 'o' ',' ' ' '日' '本' '語']
// ['H' 'e' 'l' 'l' 'o' ',' ' ' '日' '本' '語']

//_______________________________________________

//In Go Int Slice Internal Impementation
// type IntSlice struct {
// 		ptr * int
// 		len, cap int
// }

func playWithIntSlice() {
	var x []int
	x = append(x, 1)
	fmt.Println( x )

	x = append(x, 2, 3)
	fmt.Println( x )

	x = append(x, 4, 5, 6)
	fmt.Println( x )

	x = append(x, x...)
	fmt.Println( x )
}

//_______________________________________________

func removeDuplicatesFromUserInput()  {
	seen := make( map[string]bool )
	input := bufio.NewScanner( os.Stdin )

	for input.Scan() {
		line := input.Text()

		if !seen[ line ] {
			seen[ line ] = true
		}
	}

	if err := input.Err() ; err != nil {
		fmt.Fprintf( os.Stdout, "Input Error : %v", err )
	} 

	// return seen 
	fmt.Println( seen )
}

//_______________________________________________

// Associative Types

type Circle struct {
	X, Y, Radius int 
}

type Wheel struct {
	X, Y, Radius, Spokes int
}

func playWithCircleAndWheel() {
	var c Circle
	c.X = 10
	c.Y = 20
	c.Radius = 50

	fmt.Println("Circle :", c)

	var w Wheel
	w.X = 11
	w.Y = 22
	w.Radius = 55
	w.Spokes = 24

	fmt.Println("Wheel  :", w)
}

//_______________________________________________

// DRY : Don't Repeat Yourself

// https://codebunk.com/b/3741100498789/
// https://codebunk.com/b/3741100498789/
type Point1 struct {
	X int
	Y int
}

type Circle1 struct {
	Center Point1
	Radius int 
}

type Wheel1 struct {
	Circle Circle1
	Spokes int
}

func playWithCircleAndWheel1() {
	var c Circle1
	c.Center.X = 10
	c.Center.Y = 20
	c.Radius = 50

	fmt.Println("Circle 1:", c)

	var w Wheel1
	w.Circle.Center.X = 11
	w.Circle.Center.Y = 22
	w.Circle.Radius = 55
	w.Spokes = 24

	fmt.Println("Wheel 1 :", w)
}

//_______________________________________________
// MOMENT DONE! RAISE YOUR FLAGS!!!

// https://codebunk.com/b/5771100498802/
// https://codebunk.com/b/5771100498802/

type Point struct {
	X int
	Y int
}

func ScalePoint( point Point, factor int ) Point {
	return Point{ point.X * factor, point.Y * factor }
}

func AddPoints( point1 Point, point2 Point ) Point {
	return Point{ point1.X * point2.X, point1.Y + point2.Y }
}

func playWithPointType() {
	point1 := Point{ 10 , 20  }
	point2 := Point{ 100, 200 }
	point3 := Point{ 10 , 20  }

	fmt.Println("point1 :", point1 )
	fmt.Println("point2 :", point2 )
	fmt.Println("point3 :", point3 )

	fmt.Println("point1 == point2 :", point1.X == point2.X && point1.Y == point2.Y )
	fmt.Println("point1 == point2 :", point1.X == point3.X && point1.Y == point3.Y )

	fmt.Println("point1 == point2 :", point1 == point2 )
	fmt.Println("point1 == point3 :", point1 == point3 )

	fmt.Println("point1 * 10 :", ScalePoint( point1, 10 ) )
	fmt.Println("point2 * 5 :", ScalePoint( point2, 5 ) )
	fmt.Println("point3 * 7 :", ScalePoint( point3, 7 ) )

	point4 := AddPoints( point1, point2 )
	fmt.Println("point4 :", point4 )

	point5 := AddPoints( point1, point3 )
	fmt.Println("point5 :", point5 )
}


//_______________________________________________

type Point2 struct {
	X int
	Y int
}

type Circle2 struct {
	// Center Point2
	Point2      	// Type/Structure Embedding
	Radius int
}

type Wheel2 struct {
	// Circle Circle2
	Circle2        	// Type/Structure Embedding
	Spokes int
}

func playWithCircleAndWheel2(){
	var w Wheel2

	w.Circle2.Point2.X = 11
	w.Circle2.Point2.Y = 22
	w.Circle2.Radius   = 55
	w.Spokes = 24

	fmt.Println("Wheel 2 : ", w)

	// Can Access Directly Members Of The Embedded Type/Structure
	w.X = 110
	w.Y = 220
	w.Radius = 550
	w.Spokes = 240

	fmt.Println("Wheel 2 : ", w)

	var ww Wheel2
				// Circle2                         Spokes
				//					X   Y    Radius							
	ww = Wheel2{ Circle2 { Point2{ 80, 90 }, 100 }, 244 }
	fmt.Println("Wheel 2 : ", ww)

	ww = Wheel2 {
		// Can Use Labels i.e. Circle2 Is Used As Label
		Circle2 : Circle2 {
			Point2 : Point2 { 888, 999 },
			Radius : 777 },
		Spokes : 99,
	}
	
	fmt.Println("Wheel 2 : ", ww)
}

//_______________________________________________
//_______________________________________________
//_______________________________________________
//_______________________________________________

func main() {
	fmt.Println("\n\nFunction : playWithArrays")
	playWithArrays()

	fmt.Println("\n\nFunction : playWithBitwiseOperators")
	playWithBitwiseOperators()

	fmt.Println("\n\nFunction : playWithFlags")
	playWithFlags()

	fmt.Println("\n\nFunction : playWithChangeArray")
	playWithChangeArray()

	fmt.Println("\n\nFunction : playWithCorrency")
	playWithCorrency()

	fmt.Println("\n\nFunction : playWithArraysAgain")
	playWithArraysAgain()

	fmt.Println("\n\nFunction : playWithArraysAndSlices")
	playWithArraysAndSlices()

	fmt.Println("\n\nFunction : playWithArrayAndSlicesEquality")
	playWithArrayAndSlicesEquality()

	fmt.Println("\n\nFunction : playWithMonthsSlices")
	playWithMonthsSlices()

	fmt.Println("\n\nFunction : playWithModifiicationsUsingSlices")
	playWithModifiicationsUsingSlices()

	fmt.Println("\n\nFunction : playWithReverse")
	playWithReverse()

	fmt.Println("\n\nFunction : playWithEqualSlices")
	playWithEqualSlices()

	fmt.Println("\n\nFunction : playWithArraysAndSlicesFunctions")
	playWithArraysAndSlicesFunctions()

	// fmt.Println("\n\nFunction : playWithReadingUserInputs")
	// playWithReadingUserInputs()

	fmt.Println("\n\nFunction : playWithAllocate2DIntArray")
	playWithAllocate2DIntArray()

	fmt.Println("\n\nFunction : playWithAppendInt")
	playWithAppendInt()

	fmt.Println("\n\nFunction : playWithVaridiacSummationFunction")
	playWithVaridiacSummationFunction()

	fmt.Println("\n\nFunction : playWithAppendInts")
	playWithAppendInts()

	fmt.Println("\n\nFunction : playWithFilterEmpty")
	playWithFilterEmpty()

	fmt.Println("\n\nFunction : playWithMaps")
	playWithMaps()

	fmt.Println("\n\nFunction : playWithSlicesDeclarations")
	playWithSlicesDeclarations()

	fmt.Println("\n\nFunction : playWithAppendRunes")
	playWithAppendRunes()

	fmt.Println("\n\nFunction : playWithIntSlice")
	playWithIntSlice()

	fmt.Println("\n\nFunction : playWithEqualMaps")
	playWithEqualMaps()

	// fmt.Println("\n\nFunction : removeDuplicatesFromUserInput")
	// removeDuplicatesFromUserInput()

	fmt.Println("\n\nFunction : playWithCircleAndWheel")
	playWithCircleAndWheel()

	fmt.Println("\n\nFunction : playWithCircleAndWheel1")
	playWithCircleAndWheel1()

	fmt.Println("\n\nFunction : playWithPointType")
	playWithPointType()

	fmt.Println("\n\nFunction : playWithCircleAndWheel2")
	playWithCircleAndWheel2()

	// fmt.Println("\n\nFunction : ")
	// fmt.Println("\n\nFunction : ")
	// fmt.Println("\n\nFunction : ")
	// fmt.Println("\n\nFunction : ")
	// fmt.Println("\n\nFunction : ")
	// fmt.Println("\n\nFunction : ")
	// fmt.Println("\n\nFunction : ")
}


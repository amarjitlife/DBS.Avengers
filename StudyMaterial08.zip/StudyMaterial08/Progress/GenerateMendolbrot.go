
package main

import (
	"os"
	"image"
	"image/color"
	"image/png"
	"math/cmplx"
)

func mandelbrot( c complex128 ) color.Color {
	const iterations = 200
	const contrast = 15

	var z complex128
	for n := uint8( 0 ) ; n < iterations ; n++ {
		z = z * z + c 
	
		if cmplx.Abs( z ) > 2 {
			return color.Gray{ 255 - contrast * n }
		}
	}
	return color.Black
}

func generateMendelbrot() {
	const (
		xmin, ymin, xmax, ymax = -2, -2, +2, +2
		width, height = 1024, 1024
	)

	image := image.NewRGBA( image.Rect(0, 0, width, height) )

	for py := 0 ; py < height ; py++ {
		y := float64( py ) / height * ( ymax - ymin ) + ymin

		for px := 0 ; px < width ; px++ {
			x := float64( px ) / width * ( xmax - xmin ) + xmin
			c := complex( x, y )

			image.Set( px, py, mandelbrot( c ) )
		}
	}
	png.Encode( os.Stdout, image )
}

func main() {
	generateMendelbrot()
}

// https://codebunk.com/b/1121100496169/
// https://codebunk.com/b/1121100496169/
// https://codebunk.com/b/1121100496169/

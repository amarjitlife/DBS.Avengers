
#include <stdio.h>

extern int globalVariable;

void playWithGlobalVariable() {
	printf("\n Global Variable Value: %d", globalVariable );
}


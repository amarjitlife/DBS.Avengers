
class Experiments {
	public static void changeArray( int a[], int arraySize ) {
		for ( int i = 0 ; i < arraySize ; i++ ) {
			a[i] = 777;
		}
	}

	public static void playWithChangeArray() {
		int arraySize = 5;
		int[] a = { 10, 20, 30, 40, 50 };

		System.out.printf("\nArray Elements Before changeArray Call: ");
		for ( int i = 0 ; i < arraySize ; i++ ) {
			System.out.printf(" %d ", a[i] );
		}

		changeArray( a, arraySize);
		System.out.printf("\nArray Elements After changeArray Call: ");
		for ( int i = 0 ; i < arraySize ; i++ ) {
			System.out.printf(" %d ", a[i] );
		}
	}

	public static void main( String args[] ) {
		playWithChangeArray();
	}

}


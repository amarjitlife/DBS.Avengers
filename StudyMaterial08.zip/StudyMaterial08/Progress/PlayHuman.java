/*
	javac PlayHuman.java -d ClassFiles/
	java -cp ClassFiles/ examples.PlayHuman
*/

package examples;

// DESIGN PRINCIPLE
//		Design Towards Interfaces Rather Than Concrete Classes

// Always Discover Interfaces
// Interfaces Tells 
// 		What It Will Do!
interface Superpower {
	public void fly();
	public void saveWorld();
}

// Concrete Classes Tells 
//		When, Where, Which Way, How etc...

// Single Responsibility Design Principle
//		Single Unit Design
// Open-Close Principle
class Spiderman implements Superpower {
	public void fly() 		{ System.out.println("Fly Like Spiderman!") ;	    }
	public void saveWorld() { System.out.println("Save World Like Spiderman!"); }
}

class BadSuperman implements Superpower {
	public void fly() 		{ System.out.println("Fly Like Superman!") ;	    }
	public void saveWorld() { System.out.println("Save World Like Superman!"); }
}

class Superman implements Superpower {
	public void fly() 		{ System.out.println("Fly Like Superman!") ;	    }
	public void saveWorld() { System.out.println("Save World Like Superman!"); }
}

class Wonderwoman implements Superpower {
	public void fly() 		{ System.out.println("Fly Like Wonderwoman!") ;	    }
	public void saveWorld() { System.out.println("Save World Like Wonderwoman!"); }
}

// Using Inheritance Mechanism
// class Human extends Spiderman {
class HumanDesign1 extends Superman {
	// public void fly() 		{ System.out.println("Fly Like Human!") ;	    }
	// public void saveWorld() { System.out.println("Save World Like Human!"); }
	public void fly() 		{ super.fly();	     }
	public void saveWorld() { super.saveWorld(); }
}

// Using Composition Mechanism
// Single Responsibility Design Principle
//		Single Unit Design
// Open-Close Principle

// HumanDesign2 Is Polymorphic
class HumanDesign2 {
	// Embedding Object Of Required Functionality
	//		Making Explicitly Zero
	//		To Achieve Substraction	
	Superpower power = null;

	public void fly() 		{ 
		if ( power != null ) power.fly();	     
		else System.out.println("Configure Human...");
	}

	public void saveWorld() { 
		if ( power != null ) power.saveWorld();	     
		else System.out.println("Configure Human...");
	}
}

class PlayHuman {
	public static void main( String args[] ) {
		// HumanDesign1 human = new HumanDesign1();
		// human.fly();
		// human.saveWorld();
	
		HumanDesign2 human = new HumanDesign2();
		human.power = new Spiderman(); 			// Configuring Human : Giving Power To Human!
		human.fly();
		human.saveWorld();

		human.power = new BadSuperman(); 		// Configuring Human : Giving Power To Human!
		human.fly();
		human.saveWorld();

		human.power = new Superman(); 			// Configuring Human : Giving Power To Human!
		human.fly();
		human.saveWorld();

		human.power = new Wonderwoman(); 		// Configuring Human : Giving Power To Human!
		human.fly();
		human.saveWorld();
	}
}

